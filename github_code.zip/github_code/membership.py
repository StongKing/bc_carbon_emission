import numpy as np

def memberships(distance_km):
    x=np.asarray(distance_km,dtype=float)
    if np.any(~np.isfinite(x)) or np.any(x<0): raise ValueError('Distances must be finite and nonnegative.')
    foot=np.where(x<=.14,1,np.where(x<=5.9,1.253*np.exp(-1.697*x)+.0099,0))
    bike=np.select([x<=.1,x<=2.5,x<=3,x<=10],
                   [0,-1.927*np.exp(-.3008*x)+1.896,1,9.061*np.exp(-.8509*x)+.0036],default=0)
    car=np.where(x<=.7,0,np.where(x<=18.4,-1.07*np.exp(-.2538*x)+1.01,1))
    pt=np.where(x<=.9,0,np.where(x<=19.4,-1.364*np.exp(-.0835*x)+1.27,1))
    return np.column_stack([foot,bike,car,pt])

def bike_gate(distance_km, rule):
    u=memberships(distance_km)
    if (u < -1e-10).any() or (u>1+1e-10).any():
        raise ValueError('Membership values must be within [0, 1].')
    if rule=='maximum': return (u[:,1]>=np.max(u[:,[0,2,3]],axis=1)).astype(float)
    if rule=='normalized':

        return np.divide(u[:,1],u.sum(axis=1),out=np.zeros(len(u)),where=u.sum(axis=1)>0)
    if rule=='none': return np.ones(len(u))
    raise ValueError(rule)
