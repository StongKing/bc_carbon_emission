from __future__ import annotations

import itertools
import math
from typing import Any

import numpy as np
import pandas as pd


REFERENCE = "grid500_window60_capacity20"
LEGACY = "legacy_zero_gap_included"
WINDOW_MINUTES = (30, 60, 120, 360)
WINDOW_ALIGNMENT = "source_local_midnight"
_GROUP_KEYS = ["bin", "ox", "oy", "dx", "dy"]
_GROUP_BINS = ((1, 1, "1"), (2, 5, "2-5"), (6, 10, "6-10"),
               (11, 20, "11-20"), (21, 30, "21-30"),
               (31, 50, "31-50"), (51, math.inf, "51+"))
_DISTANCE_BINS = ((0, .1, "0-0.1"), (.1, 1, "0.1-1"),
                  (1, 5, "1-5"), (5, 10, "5-10"),
                  (10, 20, "10-20"), (20, 50, "20-50"),
                  (50, 100, "50-100"), (100, math.inf, "100+"))


def scenario_specs() -> list[dict[str, Any]]:


    if any(not isinstance(w, int) or w <= 0 or 1440 % w for w in WINDOW_MINUTES):
        raise ValueError("Window minutes must be positive integers dividing the 1440-minute local day.")
    reference = dict(cell=500, window=60, capacity=20, cutoff=100, maxgap=24,
                     timestamp="next_start", offset=0,
                     require_positive_gap=True, scope="all_archive")
    result = []
    for cell, window, capacity in itertools.product(
            (250, 500, 1000), WINDOW_MINUTES, (10, 20, 30)):
        result.append(dict(reference, name=f"grid{cell}_window{window}_capacity{capacity}",
                           cell=cell, window=window, capacity=capacity))
    for key, values in (("cutoff", (0, 50, 200)), ("maxgap", (6, 12, 48)),
                        ("timestamp", ("end",)), ("offset", (250,))):
        for value in values:
            cfg = dict(reference, name=f"{key}_{value}")
            cfg[key] = value
            result.append(cfg)
    result.append(dict(reference, name=LEGACY, require_positive_gap=False))
    result.append(dict(reference, name="scope_within_core", scope="within_core"))
    result.append(dict(reference, name="scope_touching_core", scope="touching_core"))
    return result


def _ratio(numerator: float, denominator: float, scale: float = 1) -> float:
    return float(scale * numerator / denominator) if denominator else math.nan


def _metadata(cfg: dict, month: str, period: str) -> dict:
    return dict(month=month, period=period, scenario=cfg["name"],
                grid_m=cfg["cell"], window_min=cfg["window"],
                window_alignment=WINDOW_ALIGNMENT,
                capacity_bikes=cfg["capacity"], cutoff_m=cfg["cutoff"],
                max_gap_h=cfg["maxgap"], time_assignment=cfg["timestamp"],
                grid_offset_m=cfg["offset"],
                require_positive_gap=cfg["require_positive_gap"], scope=cfg["scope"],
                calendar_days=pd.Period(month, freq="M").days_in_month)


def _group_summary(frame: pd.DataFrame, cfg: dict, meta: dict):


    if frame.empty:
        grouped = pd.DataFrame(columns=["size", "mean", "latest_return", "earliest_rental"])
        group_ids = np.empty(0, dtype=np.int64)
    else:
        groups = frame.groupby(_GROUP_KEYS, sort=False, dropna=False)
        grouped = groups.agg(size=("km", "size"), mean=("km", "mean"),
                             latest_return=("previous_end", "max"),
                             earliest_rental=("next_start", "min"))
        group_ids = groups.ngroup().to_numpy(dtype=np.int64)
    size = grouped["size"].to_numpy(dtype=np.int64)
    batches = np.ceil(size / cfg["capacity"]).astype(np.int64)
    proxy = batches * grouped["mean"].to_numpy(dtype=float)
    incompatible = (grouped["latest_return"].to_numpy()
                    > grouped["earliest_rental"].to_numpy())
    allocation = (proxy / size)[group_ids] if len(size) else np.empty(0)
    total_distance = float(frame["km"].sum())
    total_proxy = float(proxy.sum())
    total_batches = int(batches.sum())
    row = dict(meta, status="ok", events=int(len(frame)), batches=total_batches,
               unbatched_bicycle_km=total_distance,
               batched_geometric_proxy_km=total_proxy,
               grouped_displacement_proxy_km=total_proxy,
               group_count=int(len(size)), singleton_groups=int((size == 1).sum()),
               groups_over_capacity=int((size > cfg["capacity"]).sum()),
               maximum_group_size=int(size.max()) if len(size) else 0,
               singleton_group_pct=_ratio(int((size == 1).sum()), len(size), 100),
               groups_over_capacity_pct=_ratio(int((size > cfg["capacity"]).sum()), len(size), 100),
               events_per_batch=_ratio(len(frame), total_batches),
               proxy_share_of_unbatched_pct=_ratio(total_proxy, total_distance, 100),
               interval_incompatible_groups=int(incompatible.sum()),
               interval_incompatible_events=int(size[incompatible].sum()),
               interval_incompatible_proxy_km=float(proxy[incompatible].sum()),
               interval_incompatible_group_pct=_ratio(int(incompatible.sum()), len(size), 100),
               interval_incompatible_event_pct=_ratio(int(size[incompatible].sum()), len(frame), 100),
               interval_incompatible_proxy_pct=_ratio(float(proxy[incompatible].sum()), total_proxy, 100),
               actual_dispatch_emissions_g=math.nan)
    distribution = []
    for lower, upper, label in _GROUP_BINS:
        selected = (size >= lower) & (size <= upper)
        distribution.append(dict(meta, bin_label=label, groups=int(selected.sum()),
                                 events=int(size[selected].sum()),
                                 batches=int(batches[selected].sum()),
                                 grouped_proxy_km=float(proxy[selected].sum())))
    return row, distribution, allocation


def _category_totals(frame: pd.DataFrame, allocation: np.ndarray,
                     selected: np.ndarray) -> dict:
    return dict(events=int(selected.sum()),
                unbatched_bicycle_km=float(frame.loc[selected, "km"].sum()),
                allocated_grouped_proxy_km=float(allocation[selected].sum()))


def _audit_decomposition(frame: pd.DataFrame, allocation: np.ndarray, meta: dict,
                         region_available: bool):


    base = dict(meta, basis_scenario=meta["scenario"],
                allocation_basis="unchanged full scenario group proxy divided by group size")
    spatial = []
    if region_available:
        for category in ("within_core", "outbound", "inbound", "outside_core"):
            selected = frame["spatial_category"].to_numpy() == category
            spatial.append(dict(base, category=category, additive_within_basis=True,
                                **_category_totals(frame, allocation, selected)))
    tail = []
    km = frame["km"].to_numpy(dtype=float)
    gap = frame["gap_h"].to_numpy(dtype=float)
    for lower, upper, label in _DISTANCE_BINS:
        selected = (km >= lower) & (km < upper)
        tail.append(dict(base, audit_type="displacement_bin", bin_label=label,
                         lower_km=lower, upper_km=upper, additive_within_basis=True,
                         **_category_totals(frame, allocation, selected)))
    speed = np.divide(km, gap, out=np.full(len(gap), np.nan), where=gap > 0)
    for threshold in (20, 40, 60, 100):
        selected = np.isfinite(speed) & (speed > threshold)
        tail.append(dict(base, audit_type="minimum_required_speed_exceedance",
                         bin_label=f">{threshold} km/h", threshold_kmh=threshold,
                         threshold_role="Speed threshold comparison",
                         additive_within_basis=False,
                         **_category_totals(frame, allocation, selected)))
    tail.append(dict(base, audit_type="zero_elapsed_time", bin_label="gap=0",
                     additive_within_basis=False,
                     **_category_totals(frame, allocation, gap == 0)))
    return spatial, tail


def relocation_diagnostics(a, start, end, keep, ox, oy, dx, dy, coordvalid,
                           month, period, *, region=None, corridor_config=None) -> dict[str, Any]:


    a = np.asarray(a)
    if a.ndim != 2 or a.shape[1] < 7:
        raise ValueError("Expected a two-dimensional raw matrix with bicycle ID in column 6.")
    n = len(a)
    supplied = dict(start=start, end=end, keep=keep, ox=ox, oy=oy, dx=dx,
                    dy=dy, coordvalid=coordvalid)
    if any(len(value) != n for value in supplied.values()):
        raise ValueError("Every diagnostic input must have one value per raw record.")
    start_index = pd.DatetimeIndex(pd.to_datetime(start, errors="coerce"))
    end_index = pd.DatetimeIndex(pd.to_datetime(end, errors="coerce"))
    if start_index.tz is not None or end_index.tz is not None:
        raise ValueError("Use documented timezone-naive local timestamps consistently.")
    d = pd.DataFrame(dict(bike=np.asarray(a[:, 6], dtype=float),
                          start=start_index, end=end_index,
                          keep=pd.Series(np.asarray(keep)).fillna(False).to_numpy(dtype=bool),
                          ox=np.asarray(ox, dtype=float), oy=np.asarray(oy, dtype=float),
                          dx=np.asarray(dx, dtype=float), dy=np.asarray(dy, dtype=float),
                          coordvalid=pd.Series(np.asarray(coordvalid)).fillna(False).to_numpy(dtype=bool),
                          row=np.arange(n)))
    d = d.sort_values(["bike", "start", "row"], kind="mergesort").reset_index(drop=True)
    tied = d.duplicated(["bike", "start"], keep=False).to_numpy()
    tied_rows = d.loc[tied]
    conflicts = (tied_rows.groupby(["bike", "start"])[["ox", "oy", "dx", "dy", "end"]]
                 .nunique() > 1).any(axis=1)
    current = d.iloc[:-1]
    following = d.iloc[1:]
    bike = d["bike"].to_numpy()
    samebike = bike[:-1] == bike[1:]
    finite_bike = np.isfinite(bike[:-1]) & np.isfinite(bike[1:])
    cstart = current["start"].to_numpy(dtype="datetime64[ns]")
    cend = current["end"].to_numpy(dtype="datetime64[ns]")
    nstart = following["start"].to_numpy(dtype="datetime64[ns]")
    nend = following["end"].to_numpy(dtype="datetime64[ns]")
    valid_time = ~(np.isnat(cstart) | np.isnat(cend) | np.isnat(nstart) | np.isnat(nend))
    gap = (nstart - cend) / np.timedelta64(1, "h")
    ex = current["dx"].to_numpy(); ey = current["dy"].to_numpy()
    fx = following["ox"].to_numpy(); fy = following["oy"].to_numpy()
    delta = np.hypot(ex - fx, ey - fy)
    projected = np.isfinite(d[["ox", "oy", "dx", "dy"]].to_numpy()).all(axis=1)
    coordinate_ok = (current["coordvalid"].to_numpy() & following["coordvalid"].to_numpy()
                     & projected[:-1] & projected[1:] & np.isfinite(delta))
    duration_ok = current["keep"].to_numpy() & following["keep"].to_numpy()
    untied = ~tied[:-1] & ~tied[1:]
    month_start = np.datetime64(pd.Timestamp(f"{month}-01"), "ns")
    month_end = np.datetime64(pd.Timestamp(f"{month}-01") + pd.offsets.MonthBegin(1), "ns")
    inside_month = ((cend >= month_start) & (cend < month_end)
                    & (nstart >= month_start) & (nstart < month_end))
    reference_steps = [
        ("same_valid_bicycle", samebike & finite_bike),
        ("valid_timestamps", valid_time),
        ("both_duration_screened", duration_ok),
        ("valid_coordinates_and_projection", coordinate_ok),
        ("no_tied_rental_times", untied),
        ("nonnegative_elapsed_gap", np.isfinite(gap) & (gap >= 0)),
        ("relocation_endpoints_within_source_month", inside_month),
        ("positive_displacement", delta > 0),
        ("displacement_at_least_100m", delta >= 100),
        ("elapsed_gap_at_most_24h", gap <= 24),
        ("positive_elapsed_gap", gap > 0),
    ]
    remaining = np.ones(max(n - 1, 0), dtype=bool)
    flow = [dict(month=month, period=period, stage="all_raw_adjacent_pairs",
                 input_pairs=len(remaining), excluded_pairs=0,
                 remaining_pairs=len(remaining), basis_scenario=REFERENCE)]
    common_base = remaining.copy()
    for step, eligible in reference_steps:
        before = int(remaining.sum())
        remaining &= eligible
        flow.append(dict(month=month, period=period, stage=step, input_pairs=before,
                         excluded_pairs=before - int(remaining.sum()),
                         remaining_pairs=int(remaining.sum()), basis_scenario=REFERENCE))
        if step == "relocation_endpoints_within_source_month":
            common_base = remaining.copy()
    legacy_mask = common_base & (delta > 0) & (delta >= 100) & (gap <= 24)

    region_available = region is not None
    origin_inside = np.zeros(len(remaining), dtype=bool)
    destination_inside = np.zeros(len(remaining), dtype=bool)
    spatial_category = np.full(len(remaining), "unavailable", dtype=object)
    if region_available:
        from shapely import intersects_xy
        finite_endpoints = np.isfinite(ex) & np.isfinite(ey) & np.isfinite(fx) & np.isfinite(fy)
        origin_inside[finite_endpoints] = intersects_xy(region, ex[finite_endpoints], ey[finite_endpoints])
        destination_inside[finite_endpoints] = intersects_xy(region, fx[finite_endpoints], fy[finite_endpoints])
        spatial_category[:] = "outside_core"
        spatial_category[origin_inside & destination_inside] = "within_core"
        spatial_category[origin_inside & ~destination_inside] = "outbound"
        spatial_category[~origin_inside & destination_inside] = "inbound"

    scenarios = []; group_size = []; spatial_audit = []; tail_audit = []
    reference_frames = {}
    for cfg in scenario_specs():
        meta = _metadata(cfg, month, period)
        if cfg["scope"] != "all_archive" and not region_available:
            empty = pd.DataFrame(columns=_GROUP_KEYS + ["km", "previous_end", "next_start"])
            row, _, _ = _group_summary(empty, cfg, meta)
            for key in set(row) - set(meta) - {"status"}:
                row[key] = math.nan
            row.update(status="unavailable_missing_region")
            scenarios.append(row)
            continue
        mask = common_base & (delta > 0) & (delta >= cfg["cutoff"]) & (gap <= cfg["maxgap"])
        if cfg["require_positive_gap"]:
            mask &= gap > 0
        if cfg["scope"] == "within_core":
            mask &= origin_inside & destination_inside
        elif cfg["scope"] == "touching_core":
            mask &= origin_inside | destination_inside
        event_time = nstart[mask] if cfg["timestamp"] == "next_start" else cend[mask]


        frame = pd.DataFrame({
            "bin": event_time.astype(np.int64) // (cfg["window"] * 60 * 10**9),
            "ox": np.floor((ex[mask] - cfg["offset"]) / cfg["cell"]).astype(np.int64),
            "oy": np.floor((ey[mask] - cfg["offset"]) / cfg["cell"]).astype(np.int64),
            "dx": np.floor((fx[mask] - cfg["offset"]) / cfg["cell"]).astype(np.int64),
            "dy": np.floor((fy[mask] - cfg["offset"]) / cfg["cell"]).astype(np.int64),
            "km": delta[mask] / 1000, "gap_h": gap[mask],
            "previous_end": cend[mask], "next_start": nstart[mask],
            "spatial_category": spatial_category[mask],
        })
        row, distribution, allocation = _group_summary(frame, cfg, meta)
        scenarios.append(row); group_size.extend(distribution)
        if cfg["name"] in (REFERENCE, LEGACY):
            reference_frames[cfg["name"]] = (frame, allocation, row)
            spatial, tail = _audit_decomposition(frame, allocation, meta, region_available)
            spatial_audit.extend(spatial); tail_audit.extend(tail)

    legacy_frame, legacy_allocation, legacy_row = reference_frames[LEGACY]
    _, _, ref_row = reference_frames[REFERENCE]
    zero_gap = legacy_frame["gap_h"].to_numpy() == 0
    zero_totals = _category_totals(legacy_frame, legacy_allocation, zero_gap)
    old_valid_base = (samebike & finite_bike & duration_ok & coordinate_ok & untied
                      & valid_time & np.isfinite(gap) & (gap >= 0) & inside_month)
    audit = dict(month=month, period=period, raw_records=n,
                 raw_adjacent_pairs=max(n - 1, 0),
                 raw_adjacent_same_bike_pairs=int(samebike.sum()),
                 valid_pairs_before_gap_limit=int(old_valid_base.sum()),
                 ambiguous_tied_time_records=int(tied.sum()),
                 tied_time_groups=int(len(conflicts)),
                 tied_time_conflicting_groups=int(conflicts.sum()),
                 negative_gap_same_bike_pairs=int((samebike & (gap < 0)).sum()),
                 raw_exact_duplicate_extra_rows=int(pd.DataFrame(a).duplicated().sum()),
                 zero_gap_positive_displacement_pairs=int((common_base & (gap == 0) & (delta > 0)).sum()),
                 reference_events=int(remaining.sum()), legacy_reference_events=int(legacy_mask.sum()),
                 legacy_reference_zero_gap_events=zero_totals["events"],
                 legacy_reference_zero_gap_unbatched_bicycle_km=zero_totals["unbatched_bicycle_km"],
                 legacy_reference_zero_gap_allocated_proxy_km=zero_totals["allocated_grouped_proxy_km"],
                 reference_minus_legacy_grouped_proxy_km=(ref_row["batched_geometric_proxy_km"]
                                                        - legacy_row["batched_geometric_proxy_km"]),
                 spatial_region_available=region_available,
                 audit_count_note="Pair flags may overlap; filter_flow gives mutually exclusive exclusion counts.",
                 zero_gap_allocation_note="Legacy grouped distance allocated evenly across group members.",
                 compatibility_note="Intersection of the return-to-next-rental intervals of all group members.")
    for label, selected in (("reference", remaining), ("legacy_reference", legacy_mask)):
        distances = delta[selected]
        audit.update({f"{label}_event_displacement_median_m": float(np.median(distances)) if len(distances) else math.nan,
                      f"{label}_event_displacement_p95_m": float(np.quantile(distances, .95)) if len(distances) else math.nan,
                      f"{label}_event_displacement_max_m": float(distances.max()) if len(distances) else math.nan,
                      f"{label}_event_displacement_mean_m": float(distances.mean()) if len(distances) else math.nan,
                      f"{label}_event_gap_median_h": float(np.median(gap[selected])) if len(distances) else math.nan})
    result = dict(scenarios=scenarios, pair_audit=audit, filter_flow=flow,
                  group_size=group_size, spatial_audit=spatial_audit, tail_audit=tail_audit)
    if corridor_config is not None:
        from corridor import corridor_diagnostics
        events = pd.DataFrame({
            "event_id": np.flatnonzero(remaining),
            "bike": bike[:-1][remaining],
            "origin_x": ex[remaining], "origin_y": ey[remaining],
            "destination_x": fx[remaining], "destination_y": fy[remaining],
            "previous_end": cend[remaining], "next_start": nstart[remaining],
        })
        result["corridor"] = corridor_diagnostics(events, month, period, corridor_config)
    return result


def aggregate_period_scenarios(rows: list[dict]) -> pd.DataFrame:


    keys = ["period", "scenario", "grid_m", "window_min", "window_alignment", "capacity_bikes",
            "cutoff_m", "max_gap_h", "time_assignment", "grid_offset_m",
            "require_positive_gap", "scope", "status"]
    additive = ["calendar_days", "events", "batches", "unbatched_bicycle_km",
                "batched_geometric_proxy_km", "grouped_displacement_proxy_km",
                "group_count", "singleton_groups", "groups_over_capacity",
                "interval_incompatible_groups", "interval_incompatible_events",
                "interval_incompatible_proxy_km", "actual_dispatch_emissions_g"]
    derived = ["events_per_batch", "singleton_group_pct", "groups_over_capacity_pct",
               "proxy_share_of_unbatched_pct", "interval_incompatible_group_pct",
               "interval_incompatible_event_pct", "interval_incompatible_proxy_pct",
               "geometric_proxy_km_per_calendar_day",
               "grouped_displacement_proxy_km_per_calendar_day",
               "unbatched_bicycle_km_per_calendar_day", "events_per_calendar_day",
               "batches_per_calendar_day", "change_from_declared_scenario_pct"]
    if not rows:
        return pd.DataFrame(columns=keys + additive + ["maximum_group_size"] + derived)
    monthly = pd.DataFrame(rows)
    if monthly.duplicated(["month"] + keys).any():
        raise ValueError("Duplicate month/scenario/settings rows would double-count the period.")
    aggregations = {name: (lambda series: series.sum(min_count=1)) for name in additive}
    aggregations["maximum_group_size"] = "max"
    result = monthly.groupby(keys, sort=False, dropna=False).agg(aggregations).reset_index()

    def ratio(numerator, denominator, scale=1):
        return scale * result[numerator] / result[denominator].replace(0, np.nan)

    result["events_per_batch"] = ratio("events", "batches")
    result["singleton_group_pct"] = ratio("singleton_groups", "group_count", 100)
    result["groups_over_capacity_pct"] = ratio("groups_over_capacity", "group_count", 100)
    result["proxy_share_of_unbatched_pct"] = ratio("batched_geometric_proxy_km", "unbatched_bicycle_km", 100)
    result["interval_incompatible_group_pct"] = ratio("interval_incompatible_groups", "group_count", 100)
    result["interval_incompatible_event_pct"] = ratio("interval_incompatible_events", "events", 100)
    result["interval_incompatible_proxy_pct"] = ratio("interval_incompatible_proxy_km", "batched_geometric_proxy_km", 100)
    result["geometric_proxy_km_per_calendar_day"] = ratio("batched_geometric_proxy_km", "calendar_days")
    result["grouped_displacement_proxy_km_per_calendar_day"] = result["geometric_proxy_km_per_calendar_day"]
    result["unbatched_bicycle_km_per_calendar_day"] = ratio("unbatched_bicycle_km", "calendar_days")
    result["events_per_calendar_day"] = ratio("events", "calendar_days")
    result["batches_per_calendar_day"] = ratio("batches", "calendar_days")
    reference_rows = result[result["scenario"].eq(REFERENCE) & result["status"].eq("ok")]
    if reference_rows["period"].duplicated().any():
        raise ValueError("More than one available reference definition exists for a period.")
    reference_values = reference_rows.set_index("period")["geometric_proxy_km_per_calendar_day"]
    reference = result["period"].map(reference_values).replace(0, np.nan)
    result["change_from_declared_scenario_pct"] = 100 * (result["geometric_proxy_km_per_calendar_day"] / reference - 1)
    return result
