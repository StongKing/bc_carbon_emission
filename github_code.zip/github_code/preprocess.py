from __future__ import annotations

from pathlib import Path
from datetime import datetime, timedelta
from contextlib import ExitStack
import argparse
import gc
import hashlib
import json

import numpy as np
import pandas as pd
import scipy
from scipy.io import loadmat


PROJECT_DIR = Path(__file__).resolve().parent


MAT_DIR = PROJECT_DIR / "data"

OUTPUT_ROOT = (
    PROJECT_DIR / "results" / "preprocess"
)


TIME_POLICY = "source_seconds"


CHUNK_SIZE = 100_000


FILES = [
    (
        "dataoct.mat", "dataoct", "2019-10", "pre",
        "data_2019_oct.csv", 1398611, 1365176,
    ),
    (
        "datafeb.mat", "datafeb", "2020-02", "outbreak",
        "data_2020_feb.csv", 101580, 99392,
    ),
    (
        "datamarch.mat", "datamarch", "2020-03", "outbreak",
        "data_2020_march.csv", 445237, 437440,
    ),
    (
        "datajune.mat", "datajune", "2020-06", "later",
        "data_2020_june.csv", 1609405, 1585744,
    ),
]


COLS = [
    "a1.begun_time",
    "a1.finished_time",
    "a1.starting_lng",
    "a1.starting_lat",
    "a1.dest_lng",
    "a1.dest_lat",
    "a1.vehicle_id",
    "is_mkt_card",
    "a3.birth_year",
]


CLEAN_COLS = COLS + [
    "trip_id",
    "source_row",
    "start_time",
    "end_time",
    "bike_id",
    "duration_seconds",
    "duration_min",
    "coordinate_fields_valid",
    "same_od_exact",
]


def save_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
        float_format="%.17g",
        date_format="%Y-%m-%d %H:%M:%S.%f",
    )


def sha256(path: Path) -> str:

    h = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(
            lambda: stream.read(1024 * 1024), b""
        ):
            h.update(block)

    return h.hexdigest()


def read_matrix(path: Path, key: str) -> np.ndarray:

    try:
        content = loadmat(
            path,
            variable_names=[key],
            squeeze_me=False,
        )
    except NotImplementedError as exc:
        raise RuntimeError(
            f"{path.name}可能为MAT v7.3，"
            "scipy.io.loadmat不能直接读取。"
            "请使用 MATLAB v7 或更早版本的 MAT 文件。"
        ) from exc

    if key not in content:
        raise KeyError(
            f"{path.name}中没有变量：{key}"
        )

    a = content[key]

    if (
        not isinstance(a, np.ndarray)
        or a.ndim != 2
        or a.shape[1] != 9
    ):
        raise ValueError(
            f"{path.name}/{key}应为N×9矩阵，"
            f"实际：{getattr(a, 'shape', None)}"
        )

    if a.dtype.kind not in "iuf":
        raise TypeError(
            f"{path.name}/{key}不是实数数值矩阵：{a.dtype}"
        )

    if len(a) == 0:
        raise ValueError(
            f"{path.name}/{key}为空矩阵。"
        )

    return a


def convert_datenum(values: np.ndarray) -> pd.Series:


    def convert(value):
        value = float(value)

        if not np.isfinite(value):
            return None

        try:
            days = int(value)

            return (
                datetime.fromordinal(days - 366)
                + timedelta(
                    seconds=(value - days) * 24 * 3600
                )
            )
        except (ValueError, OverflowError):
            return None


    objects = [convert(v) for v in values]

    return pd.Series(
        pd.to_datetime(objects, errors="coerce")
    )


def seconds_between(
    start: pd.Series,
    end: pd.Series,
) -> pd.Series:

    delta = (
        end.to_numpy(dtype="datetime64[us]")
        - start.to_numpy(dtype="datetime64[us]")
    )

    return pd.Series(
        delta / np.timedelta64(1, "s"),
        index=start.index,
    )


def time_reason(seconds: pd.Series) -> pd.Series:

    result = pd.Series("KEEP", index=seconds.index)

    finite = np.isfinite(seconds)

    result.loc[~finite] = "TIME_UNCONVERTIBLE"

    result.loc[
        finite & seconds.lt(60)
    ] = "DURATION_LT_60S"

    result.loc[
        finite & seconds.gt(7200)
    ] = "DURATION_GT_7200S"

    return result


def id_text(value):


    if not np.isfinite(value):
        return None

    if value == int(value):
        return str(int(value))

    return str(value)


def prepare(
    a: np.ndarray,
    key: str,
) -> pd.DataFrame:

    start_full = convert_datenum(a[:, 0])
    end_full = convert_datenum(a[:, 1])


    start_sec = start_full.dt.floor("s")
    end_sec = end_full.dt.floor("s")

    full_seconds = seconds_between(
        start_full, end_full
    )

    source_seconds = seconds_between(
        start_sec, end_sec
    )


    with np.errstate(invalid="ignore", over="ignore"):
        dn_seconds = pd.Series(
            (
                a[:, 1].astype(float)
                - a[:, 0].astype(float)
            ) * 86400
        )

    if TIME_POLICY == "source_seconds":
        start = start_sec
        end = end_sec
        duration = source_seconds
    else:
        start = start_full
        end = end_full
        duration = full_seconds


    d = pd.DataFrame(a, columns=COLS)

    d[COLS[0]] = start
    d[COLS[1]] = end


    d["source_row"] = np.arange(
        1, len(d) + 1, dtype=np.int64
    )


    d["trip_id"] = [
        f"{key}:{i}" for i in d["source_row"]
    ]

    d["start_time"] = start
    d["end_time"] = end

    d["bike_id"] = (
        d["a1.vehicle_id"].map(id_text)
    )


    d["matlab_start_datenum"] = a[:, 0]
    d["matlab_end_datenum"] = a[:, 1]

    d["start_time_full"] = start_full
    d["end_time_full"] = end_full

    d["duration_source_seconds"] = source_seconds
    d["duration_full_seconds"] = full_seconds
    d["duration_datenum_seconds"] = dn_seconds

    d["duration_seconds"] = duration
    d["duration_min"] = duration / 60


    d["keep_source_seconds"] = (
        source_seconds.between(60, 7200)
    )

    d["keep_microseconds"] = (
        full_seconds.between(60, 7200)
    )

    d["keep_datenum"] = (
        dn_seconds.between(60, 7200)
        & start_full.notna()
        & end_full.notna()
    )


    d["screening_reason"] = time_reason(duration)

    d["keep_duration"] = (
        d["screening_reason"].eq("KEEP")
    )

    d["precision_changes_selection"] = (
        d["keep_source_seconds"].ne(
            d["keep_microseconds"]
        )
        | d["keep_microseconds"].ne(
            d["keep_datenum"]
        )
    )


    xy = a[:, 2:6].astype(float)

    valid_xy = (
        np.isfinite(xy).all(axis=1)
        & (
            np.abs(xy[:, [0, 2]]) <= 180
        ).all(axis=1)
        & (
            np.abs(xy[:, [1, 3]]) <= 90
        ).all(axis=1)
    )

    d["coordinate_fields_valid"] = valid_xy


    d["same_od_exact"] = (
        valid_xy
        & (xy[:, 0] == xy[:, 2])
        & (xy[:, 1] == xy[:, 3])
    )


    return (
        d.sort_values(
            "start_time",
            kind="mergesort",
            na_position="last",
        )
        .reset_index(drop=True)
    )


def export_records(
    d: pd.DataFrame,
    out: Path,
    filename: str,
) -> dict:

    counts = {
        "all_records": 0,
        "cleaned": 0,
        "excluded": 0,
        "precision_changed": 0,
    }

    with ExitStack() as stack:
        handles = {
            folder: stack.enter_context(
                (out / folder / filename).open(
                    "w",
                    encoding="utf-8-sig",
                    newline="",
                )
            )
            for folder in counts
        }

        for offset in range(
            0, len(d), CHUNK_SIZE
        ):
            part = d.iloc[
                offset:offset + CHUNK_SIZE
            ]

            groups = {
                "all_records": part,

                "cleaned": part.loc[
                    part.keep_duration,
                    CLEAN_COLS,
                ],

                "excluded": part.loc[
                    ~part.keep_duration
                ],

                "precision_changed": part.loc[
                    part.precision_changes_selection
                ],
            }

            for folder, block in groups.items():
                block.to_csv(
                    handles[folder],
                    index=False,
                    header=(offset == 0),
                    float_format="%.17g",
                    date_format="%Y-%m-%d %H:%M:%S.%f",
                )

                counts[folder] += len(block)

    if counts["all_records"] != len(d):
        raise RuntimeError(
            "全量导出数量与MAT行数不一致。"
        )

    if (
        counts["cleaned"]
        + counts["excluded"]
        != len(d)
    ):
        raise RuntimeError(
            "保留数与排除数之和不等于MAT行数。"
        )

    return counts


def summarize(
    d: pd.DataFrame,
    spec: tuple,
    out: Path,
    written: dict,
):
    (
        filename, key, month, period,
        csvname, paper_n, previous_n,
    ) = spec

    keep = d.keep_duration
    dates = d.start_time.dt.normalize()

    expected = pd.date_range(
        month + "-01",
        periods=pd.Period(month).days_in_month,
    )

    in_month = dates.isin(expected)

    reason = d.screening_reason.value_counts()


    daily_source = pd.DataFrame({
        "date": dates,
        "raw_rows": 1,
        "kept_rows": keep.astype(int),
        "kept_seconds": (
            d.duration_seconds.where(keep, 0)
        ),
    })

    daily = daily_source.groupby("date").sum()

    daily = (
        daily.reindex(
            daily.index.union(expected),
            fill_value=0,
        )
        .sort_index()
    )

    daily.index.name = "date"

    daily["raw_rows"] = (
        daily.raw_rows.astype("int64")
    )

    daily["kept_rows"] = (
        daily.kept_rows.astype("int64")
    )

    daily["mean_duration_min"] = (
        daily.kept_seconds
        / daily.kept_rows.replace(0, np.nan)
        / 60
    )

    daily["source_month"] = month
    daily["source_period"] = period

    daily["within_expected_month"] = (
        daily.index.isin(expected)
    )

    daily["count_basis"] = "source_file_records"

    daily = daily.reset_index()

    if (
        int(daily.kept_rows.sum())
        != int(keep.sum())
    ):
        raise RuntimeError(
            "逐日统计与保留样本数量不一致。"
        )


    freq = (
        d.loc[keep, "bike_id"]
        .value_counts()
        .rename_axis("bike_id")
        .rename("kept_trips")
        .to_frame()
    )

    freq["above_monthly_mean"] = (
        freq.kept_trips.gt(
            freq.kept_trips.mean()
        )
    )

    save_csv(
        freq.reset_index(),
        out / "statistics"
        / f"bicycle_frequency_{month}.csv",
    )


    n = int(keep.sum())

    row = dict(
        month=month,
        period=period,
        time_policy=TIME_POLICY,

        mat_rows=len(d),
        exported_all_rows=written["all_records"],

        time_unconvertible=int(
            reason.get("TIME_UNCONVERTIBLE", 0)
        ),

        removed_lt_60s=int(
            reason.get("DURATION_LT_60S", 0)
        ),

        removed_gt_7200s=int(
            reason.get("DURATION_GT_7200S", 0)
        ),

        kept_records=n,

        kept_source_seconds=int(
            d.keep_source_seconds.sum()
        ),

        kept_microseconds=int(
            d.keep_microseconds.sum()
        ),

        kept_datenum=int(
            d.keep_datenum.sum()
        ),

        precision_changed_records=int(
            d.precision_changes_selection.sum()
        ),

        source_keeps_microseconds_excludes=int(
            (
                d.keep_source_seconds
                & ~d.keep_microseconds
            ).sum()
        ),

        microseconds_keeps_source_excludes=int(
            (
                d.keep_microseconds
                & ~d.keep_source_seconds
            ).sum()
        ),

        total_kept_duration_seconds=float(
            d.loc[
                keep, "duration_seconds"
            ].sum()
        ),

        mean_duration_min=float(
            d.loc[keep, "duration_min"].mean()
        ),

        calendar_days=len(expected),

        dates_with_raw_records=int(
            dates.nunique()
        ),

        dates_with_kept_records=int(
            dates[keep].nunique()
        ),

        raw_outside_expected_month=int(
            (
                dates.notna() & ~in_month
            ).sum()
        ),

        kept_outside_expected_month=int(
            (
                keep & ~in_month
            ).sum()
        ),


        kept_per_calendar_day=(
            n / len(expected)
            if not (keep & ~in_month).any()
            else np.nan
        ),

        observed_active_bikes=len(freq),

        mean_trips_per_identified_active_bike=float(
            freq.kept_trips.mean()
        ),

        active_bikes_above_mean_pct=float(
            100 * freq.above_monthly_mean.mean()
        ),

        kept_missing_bike_id=int(
            d.loc[keep, "bike_id"].isna().sum()
        ),

        kept_invalid_coordinate_fields=int(
            (
                keep
                & ~d.coordinate_fields_valid
            ).sum()
        ),

        same_od_exact_count=int(
            (
                keep & d.same_od_exact
            ).sum()
        ),

        paper_reported_trips=paper_n,


        previous_csv_rows_reported=previous_n,

        mat_minus_paper=len(d) - paper_n,

        mat_minus_previous_csv=(
            len(d) - previous_n
        ),

        kept_minus_paper=n - paper_n,
    )

    accounted = (
        row["time_unconvertible"]
        + row["removed_lt_60s"]
        + row["removed_gt_7200s"]
        + n
    )

    if accounted != len(d):
        raise RuntimeError(
            "筛选原因计数不守恒。"
        )

    return row, daily


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Convert MATLAB trip records and summarize trips lasting 1 to 120 minutes.")
    parser.add_argument("--data-dir", type=Path, default=MAT_DIR, help="Directory containing the MAT input files.")
    parser.add_argument("--output-root", type=Path, default=OUTPUT_ROOT, help="Directory for timestamped output runs.")
    parser.add_argument("--months", nargs="+", choices=[spec[2] for spec in FILES], default=[spec[2] for spec in FILES], help="One or more months to process.")
    parser.add_argument("--time-policy", choices=["source_seconds", "preserve_microseconds"], default=TIME_POLICY)
    parser.add_argument("--chunk-size", type=int, default=CHUNK_SIZE)
    args = parser.parse_args(argv)
    if len(args.months) != len(set(args.months)):
        parser.error("--months must contain unique values")
    if args.chunk_size <= 0:
        parser.error("--chunk-size must be greater than zero")
    return args


def main(argv=None) -> None:
    global MAT_DIR, OUTPUT_ROOT, TIME_POLICY, CHUNK_SIZE
    args = parse_args(argv)
    MAT_DIR = args.data_dir.expanduser().resolve()
    OUTPUT_ROOT = args.output_root.expanduser().resolve()
    TIME_POLICY = args.time_policy
    CHUNK_SIZE = args.chunk_size
    selected = [spec for spec in FILES if spec[2] in args.months]

    if TIME_POLICY not in {
        "source_seconds",
        "preserve_microseconds",
    }:
        raise ValueError(
            "TIME_POLICY应为source_seconds"
            "或preserve_microseconds。"
        )


    for spec in selected:
        path = MAT_DIR / spec[0]

        if not path.is_file():
            raise FileNotFoundError(
                f"找不到 MAT 输入文件：{path}"
            )


    out = OUTPUT_ROOT / datetime.now().strftime(
        "run_%Y%m%d_%H%M%S_%f"
    )

    for folder in [
        "all_records",
        "cleaned",
        "excluded",
        "precision_changed",
        "statistics",
    ]:
        (out / folder).mkdir(
            parents=True,
            exist_ok=False,
        )

    print("MAT输入目录：", MAT_DIR.resolve())
    print("输出目录：", out.resolve())
    print("主时间口径：", TIME_POLICY)

    manifest = {
        "status": "RUNNING",

        "time_policy": TIME_POLICY,

        "filter": (
            "60 <= duration_seconds <= 7200"
        ),

        "timezone": (
            "source datetime values"
        ),

        "days": (
            "calendar days for each selected month"
        ),

        "versions": {
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
        },

        "inputs": [],
    }

    rows = []
    daily_tables = []

    try:
        for spec in selected:
            (
                filename, key, month, _,
                csvname, _, _,
            ) = spec

            path = MAT_DIR / filename

            print(
                f"\n读取 {filename} / {key} ...",
                flush=True,
            )

            a = read_matrix(path, key)

            manifest["inputs"].append({
                "path": str(path.resolve()),
                "variable": key,
                "shape": list(a.shape),
                "dtype": str(a.dtype),
                "sha256": sha256(path),
            })

            print(
                f"MAT原始行数：{len(a):,}；"
                "开始转换时间。",
                flush=True,
            )

            d = prepare(a, key)

            if len(d) != len(a):
                raise RuntimeError(
                    "转换阶段改变了行数。"
                )

            del a

            written = export_records(
                d, out, csvname
            )

            row, daily = summarize(
                d, spec, out, written
            )

            rows.append(row)
            daily_tables.append(daily)


            save_csv(
                pd.DataFrame(rows),
                out / "statistics"
                / "monthly_summary.csv",
            )

            print(
                f"{month}：全量 {len(d):,}；"
                f"保留 {row['kept_records']:,}；"
                "精度导致筛选差异 "
                f"{row['precision_changed_records']:,}。"
            )

            if row["raw_outside_expected_month"]:
                print(
                    f"目标月份外记录数：{row['raw_outside_expected_month']:,}"
                )

            del d
            gc.collect()

        monthly = pd.DataFrame(rows)

        save_csv(
            pd.concat(
                daily_tables,
                ignore_index=True,
            ),
            out / "statistics"
            / "daily_summary.csv",
        )


        additive = [
            "mat_rows",
            "kept_records",
            "time_unconvertible",
            "removed_lt_60s",
            "removed_gt_7200s",
            "calendar_days",
            "total_kept_duration_seconds",
            "kept_outside_expected_month",
            "paper_reported_trips",
            "previous_csv_rows_reported",
        ]

        periods = (
            monthly.groupby(
                "period", sort=False
            )[additive]
            .sum()
        )

        periods.loc["ALL"] = (
            monthly[additive].sum()
        )

        periods["mean_duration_min"] = (
            periods.total_kept_duration_seconds
            / periods.kept_records.replace(
                0, np.nan
            )
            / 60
        )

        periods["kept_per_calendar_day"] = (
            periods.kept_records
            / periods.calendar_days
        ).where(
            periods.kept_outside_expected_month.eq(0)
        )

        periods["kept_minus_paper"] = (
            periods.kept_records
            - periods.paper_reported_trips
        )

        save_csv(
            periods.reset_index(),
            out / "statistics"
            / "period_summary.csv",
        )

        manifest["status"] = "COMPLETED"

    except Exception as exc:
        manifest["status"] = "FAILED"
        manifest["error"] = str(exc)
        raise

    finally:
        (out / "run_info.json").write_text(
            json.dumps(
                manifest,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )

    show = [
        "month",
        "mat_rows",
        "kept_records",
        "kept_source_seconds",
        "kept_microseconds",
        "paper_reported_trips",
        "mat_minus_previous_csv",
    ]

    print(
        "\n",
        monthly[show].to_string(index=False),
    )

    print("\n完成：", out.resolve())


if __name__ == "__main__":
    main()
