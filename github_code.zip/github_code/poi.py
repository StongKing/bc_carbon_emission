from pathlib import Path
from datetime import datetime
from itertools import combinations
import argparse
import hashlib
import json

import numpy as np
import pandas as pd
import geopandas as gpd
import pyogrio


from shapely import union_all, make_valid
from shapely.geometry import Polygon, MultiPolygon, GeometryCollection
from shapely.validation import explain_validity


CODE_DIR = Path(__file__).resolve().parent
DATA_DIR = CODE_DIR / "data"


BOUNDARY_DIR = DATA_DIR / "eight_region"


POI_FILES = {
    "bus": DATA_DIR / "公交站点" / "公交站_点.shp",
    "school": DATA_DIR / "学校教育" / "学校_点.shp",
}


ENCODING = {
    "boundary": None,
    "bus": None,
    "school": None,
}

CORE_SIX = [
    "玄武区",
    "秦淮区",
    "建邺区",
    "鼓楼区",
    "栖霞区",
    "雨花台区",
]

DISTRICTS = CORE_SIX


METRIC_CRS = "EPSG:32650"


BUFFER_M = 300.0

OUTPUT_ROOT = (
    CODE_DIR / "results" / "poi"
)


def csv_out(frame, path):
    frame.to_csv(
        path,
        index=False,
        encoding="utf-8-sig",
        float_format="%.17g",
    )


def resolve_poi(path):

    if path.is_file():
        return path

    matches = sorted(DATA_DIR.rglob(path.name))

    if len(matches) == 1:
        print("找到POI：", matches[0])
        return matches[0]

    raise FileNotFoundError(
        f"POI 文件路径：{path}\n"
        f"同名候选：{[str(p) for p in matches]}；需要唯一匹配。"
    )


def check_parts(path):

    if not path.is_file():
        raise FileNotFoundError(f"找不到：{path}")

    parts = {
        p.suffix.lower(): p
        for p in path.parent.iterdir()
        if p.stem.lower() == path.stem.lower()
    }

    required = {".shp", ".shx", ".dbf", ".prj"}
    missing = required - set(parts)

    if missing:
        raise FileNotFoundError(
            f"{path.name}缺少配套文件：{sorted(missing)}"
        )

    return parts


def digest(path):

    h = hashlib.sha256()

    with path.open("rb") as stream:
        for block in iter(
            lambda: stream.read(1024 * 1024), b""
        ):
            h.update(block)

    return h.hexdigest()


def read_layer(path, tag, audit, geometry_only=False):
    parts = check_parts(path)

    kwargs = {"fid_as_index": True}

    if geometry_only:

        kwargs["columns"] = []

    if ENCODING[tag]:
        kwargs["encoding"] = ENCODING[tag]

    try:
        g = pyogrio.read_dataframe(path, **kwargs)
    except UnicodeError as exc:
        raise ValueError(
            f"{path.name}解码失败，"
            "请使用 --encoding 指定文件编码。"
        ) from exc

    if g.empty or g.crs is None:
        raise ValueError(
            f"{path.name}为空或没有可识别的源坐标系。"
        )

    if not g.index.is_unique:
        raise ValueError(
            f"{path.name}的源要素ID不唯一。"
        )


    if any(
        text in str(g.crs).upper()
        for text in ["GCJ", "BD09", "BD-09"]
    ):
        raise ValueError(
            "输入坐标系包含 GCJ 或 BD09 标记，请先转换为投影支持的坐标系。"
        )

    if g.geometry.name != "geometry":
        g = g.rename_geometry("geometry")

    audit["inputs"].append({
        "path": str(path.resolve()),
        "read_records": len(g),
        "declared_crs": g.crs.to_wkt(),
        "encoding_override": ENCODING[tag],
        "sha256": {
            p.name: digest(p)
            for suffix, p in parts.items()
            if suffix in [
                ".shp", ".shx", ".dbf", ".prj", ".cpg"
            ]
        },
    })

    print(
        f"读取 {path.name}：{len(g):,}条；"
        f"声明CRS：{g.crs}"
    )

    return g

def repair_polygon_geometry(geom, district):


    if geom is None or geom.is_empty:
        raise ValueError(
            f"{district}存在空几何。"
        )

    original_type = geom.geom_type
    original_valid = geom.is_valid
    invalid_reason = (
        ""
        if original_valid
        else explain_validity(geom)
    )


    if (
        original_valid
        and original_type in ["Polygon", "MultiPolygon"]
    ):
        return geom, {
            "district": district,
            "original_type": original_type,
            "original_valid": True,
            "invalid_reason": "",
            "repair_applied": False,
            "repaired_type": original_type,
        }

    print(
        f"\n修复{district}边界几何。"
    )
    print("原几何类型：", original_type)
    print("无效原因：", invalid_reason)


    repaired = make_valid(geom)


    if isinstance(repaired, GeometryCollection):
        polygons = []

        for part in repaired.geoms:
            if isinstance(part, Polygon):
                polygons.append(part)

            elif isinstance(part, MultiPolygon):
                polygons.extend(list(part.geoms))

        if not polygons:
            raise ValueError(
                f"{district}执行make_valid后"
                "没有得到任何Polygon。"
            )

        repaired = union_all(polygons)


    if repaired.geom_type not in [
        "Polygon",
        "MultiPolygon",
    ]:
        raise ValueError(
            f"{district}修复后为"
            f"{repaired.geom_type}，"
            "不能作为行政区面使用。"
        )

    if repaired.is_empty:
        raise ValueError(
            f"{district}修复后几何为空。"
        )

    if not repaired.is_valid:
        raise ValueError(
            f"{district}make_valid后仍无效："
            f"{explain_validity(repaired)}"
        )

    print(
        f"{district}修复成功："
        f"{original_type} -> {repaired.geom_type}"
    )

    return repaired, {
        "district": district,
        "original_type": original_type,
        "original_valid": original_valid,
        "invalid_reason": invalid_reason,
        "repair_applied": True,
        "repaired_type": repaired.geom_type,
    }


def load_boundaries(audit, out):
    rows = []
    repair_records = []

    for district in DISTRICTS:

        path = BOUNDARY_DIR / f"{district}.shp"

        b = read_layer(
            path,
            "boundary",
            audit,
            geometry_only=True,
        )


        if b.geometry.isna().any():
            raise ValueError(
                f"{district}存在空geometry。"
            )

        if b.geometry.is_empty.any():
            raise ValueError(
                f"{district}存在empty geometry。"
            )


        repaired_parts = []

        for idx, geom in enumerate(b.geometry):

            fixed, record = repair_polygon_geometry(
                geom,
                district,
            )

            record["feature_index"] = int(idx)

            repaired_parts.append(fixed)
            repair_records.append(record)


        temp = gpd.GeoDataFrame(
            {
                "district": [
                    district
                ] * len(repaired_parts),
            },
            geometry=repaired_parts,
            crs=b.crs,
        )

        projected = temp.to_crs(METRIC_CRS)


        geom = union_all(
            projected.geometry.to_numpy()
        )

        if geom.is_empty:
            raise ValueError(
                f"{district}合并后几何为空。"
            )

        if geom.geom_type not in [
            "Polygon",
            "MultiPolygon",
        ]:
            raise ValueError(
                f"{district}合并后不是面："
                f"{geom.geom_type}"
            )

        if not geom.is_valid:
            raise ValueError(
                f"{district}投影合并后仍无效："
                f"{explain_validity(geom)}"
            )

        area_km2 = geom.area / 1e6

        if not np.isfinite(area_km2):
            raise ValueError(
                f"{district}面积计算异常。"
            )

        rows.append({
            "district": district,
            "boundary_file": path.name,
            "input_features": len(b),
            "area_km2": area_km2,
            "geometry": geom,
        })

        print(
            f"{district}："
            f"面积约 {area_km2:.2f} km^2"
        )


    six = gpd.GeoDataFrame(
        rows,
        geometry="geometry",
        crs=METRIC_CRS,
    )


    repair_df = pd.DataFrame(
        repair_records
    )

    csv_out(
        repair_df,
        out / "boundary_geometry_repair_audit.csv",
    )


    overlaps = []

    for i, j in combinations(
        range(len(six)), 2
    ):

        ga = six.geometry.iloc[i]
        gb = six.geometry.iloc[j]

        district_a = six.district.iloc[i]
        district_b = six.district.iloc[j]

        if ga.equals(gb):
            raise ValueError(
                f"{district_a}和{district_b}"
                "边界几何完全相同。"
            )

        overlap_area = (
            ga.intersection(gb).area
        )

        overlaps.append({
            "district_a": district_a,
            "district_b": district_b,
            "overlap_m2": overlap_area,
            "overlap_km2": (
                overlap_area / 1e6
            ),
        })

    overlap = pd.DataFrame(overlaps)

    csv_out(
        overlap,
        out / "boundary_overlap_check.csv",
    )


    abnormal = overlap.loc[
        overlap.overlap_m2 > 100
    ]

    if not abnormal.empty:

        print(
            "\n超过100 m^2的行政区边界重叠："
        )

        print(
            abnormal.to_string(index=False)
        )

        print(
            "重叠面积已写入 boundary_overlap_check.csv。"
        )


    csv_out(
        six.drop(columns="geometry"),
        out / "boundary_summary.csv",
    )

    six.to_file(
        out / "six_district_boundaries.gpkg",
        layer="districts",
        driver="GPKG",
        engine="pyogrio",
        index=False,
    )

    return six


def geo_out(g, stem):
    csv_out(
        g.drop(columns="geometry"),
        stem.with_suffix(".csv"),
    )


    if not g.empty:
        g.to_file(
            stem.with_suffix(".gpkg"),
            layer="poi",
            driver="GPKG",
            engine="pyogrio",
            index=False,
        )


def extract(tag, path, six, audit, out):
    raw = read_layer(path, tag, audit)

    attrs = [
        c for c in raw.columns
        if c != "geometry"
    ]


    rename = {
        c: f"src_{i:03d}_{c}"
        for i, c in enumerate(attrs)
    }


    schema = pd.DataFrame([
        {
            "source_field": c,
            "output_field": rename[c],
            "dtype": str(raw[c].dtype),
            "missing_count": int(raw[c].isna().sum()),
            "unique_nonmissing": int(raw[c].nunique()),
        }
        for c in attrs
    ])

    csv_out(
        schema,
        out / f"{tag}_fields.csv",
    )

    csv_out(
        raw[attrs].head(30),
        out / f"{tag}_attribute_sample.csv",
    )

    print("原始字段：", attrs)
    print(raw[attrs].head(3).to_string(index=False))


    bad = (
        raw.geometry.isna()
        | raw.geometry.is_empty
        | ~raw.geometry.is_valid
        | ~raw.geom_type.eq("Point")
    )

    good_ids = raw.index[~bad]

    xy = pd.DataFrame({
        "x": raw.loc[good_ids].geometry.x,
        "y": raw.loc[good_ids].geometry.y,
    })

    bad.loc[good_ids] |= (
        ~np.isfinite(xy.to_numpy()).all(axis=1)
    )

    rejected = (
        raw.loc[bad, attrs]
        .rename(columns=rename)
        .copy()
    )

    rejected.insert(
        0,
        "audit_source_fid",
        raw.index[bad],
    )

    csv_out(
        rejected,
        out / f"{tag}_invalid_geometry.csv",
    )

    if bad.any():
        print(
            f"{tag}：{int(bad.sum())}条非有效单点"
            "已单独列出，不参与空间计数。"
        )

    if (~bad).sum() == 0:
        raise ValueError(
            f"{tag}没有有效单点，查看invalid_geometry输出。"
        )


    p = (
        raw.loc[~bad]
        .rename(columns=rename)
        .copy()
    )

    p["source_fid"] = p.index.to_numpy()
    p["poi_id"] = [f"{tag}:{fid}" for fid in p.index]
    p["source_file"] = path.name
    p["source_crs"] = str(raw.crs)

    p["source_x"] = p.geometry.x
    p["source_y"] = p.geometry.y

    dup_extra = int(
        p.duplicated(["source_x", "source_y"]).sum()
    )


    p["same_xy_in_source"] = p.duplicated(
        ["source_x", "source_y"],
        keep=False,
    )

    p = p.to_crs(METRIC_CRS)
    p["x_m"] = p.geometry.x
    p["y_m"] = p.geometry.y

    if not np.isfinite(
        p[["x_m", "y_m"]].to_numpy()
    ).all():
        raise ValueError(
            f"{tag}投影出现非有限坐标，请核查源CRS。"
        )


    xmin, ymin, xmax, ymax = six.total_bounds

    nearby = (
        p.x_m.between(
            xmin - BUFFER_M,
            xmax + BUFFER_M,
        )
        & p.y_m.between(
            ymin - BUFFER_M,
            ymax + BUFFER_M,
        )
    )

    p = p.loc[nearby].copy()

    region = union_all(six.geometry.to_numpy())


    p["distance_to_six_m"] = (
        p.geometry.distance(region)
    )

    p = p.loc[
        p.distance_to_six_m.le(BUFFER_M)
    ].copy()


    hits = gpd.sjoin(
        p[["geometry"]],
        six[["district", "geometry"]],
        how="inner",
        predicate="intersects",
    )

    names = (
        hits.groupby(level=0).district
        .agg(lambda s: "|".join(sorted(set(s))))
    )

    numbers = (
        hits.groupby(level=0).district.nunique()
    )

    p["district_hits"] = (
        p.index.to_series()
        .map(names)
        .fillna("")
    )

    p["district_hit_count"] = (
        p.index.to_series()
        .map(numbers)
        .fillna(0)
        .astype(int)
    )

    p["district"] = p.district_hits

    p.loc[
        p.district_hit_count.eq(0),
        "district",
    ] = f"六区外{BUFFER_M:g}m候选带"

    p.loc[
        p.district_hit_count.gt(1),
        "district",
    ] = "多区匹配"

    core = p.loc[
        p.district_hit_count.gt(0)
    ].copy()

    pending = core.loc[
        core.district_hit_count.gt(1)
    ]


    geo_out(
        core,
        out / f"{tag}_six_districts",
    )

    geo_out(
        p,
        out / f"{tag}_six_plus_{BUFFER_M:g}m",
    )

    csv_out(
        pending.drop(columns="geometry"),
        out / f"{tag}_boundary_review.csv",
    )

    csv_out(
        core.loc[core.same_xy_in_source]
        .drop(columns="geometry"),
        out / f"{tag}_same_coordinate_review.csv",
    )

    folder = out / f"{tag}_by_district"
    folder.mkdir()

    for name in DISTRICTS:
        csv_out(
            core.loc[core.district.eq(name)]
            .drop(columns="geometry"),
            folder / f"{name}.csv",
        )

    counts = (
        core.district.value_counts()
        .reindex(DISTRICTS, fill_value=0)
    )


    if int(counts.sum()) + len(pending) != len(core):
        raise RuntimeError(
            "分区计数与六区合计不守恒。"
        )


    type_tables = []

    for c in attrs:
        if not any(
            word in c.lower()
            for word in [
                "type", "class", "类型", "类别",
                "大类", "中类", "小类",
            ]
        ):
            continue

        all_n = (
            raw[c].astype("string")
            .fillna("<缺失>")
            .value_counts()
        )

        six_n = (
            core[rename[c]].astype("string")
            .fillna("<缺失>")
            .value_counts()
        )

        t = pd.concat(
            [
                all_n.rename("input_records"),
                six_n.rename("six_records"),
            ],
            axis=1,
        ).fillna(0).astype(int)

        t.index.name = "value"
        t = t.reset_index()
        t.insert(0, "field", c)

        type_tables.append(t)

    if type_tables:
        types = pd.concat(
            type_tables,
            ignore_index=True,
        )
    else:
        types = pd.DataFrame(columns=[
            "field",
            "value",
            "input_records",
            "six_records",
        ])

    csv_out(
        types,
        out / f"{tag}_type_counts.csv",
    )

    summary = {
        "layer": tag,
        "input_read_records": len(raw),
        "invalid_geometry_records": int(bad.sum()),
        "valid_point_records": int((~bad).sum()),
        "extra_records_at_identical_xy_input": dup_extra,
        "six_records": len(core),
        "six_unique_xy": len(
            core[["source_x", "source_y"]]
            .drop_duplicates()
        ),
        "pending_district_assignment": len(pending),
        "six_plus_buffer_records": len(p),
        "buffer_only_records": len(p) - len(core),
        "type_fields_found": len(type_tables),
    }

    print(
        f"{tag}：六区{len(core):,}；"
        f"多区匹配{len(pending):,}；"
        f"六区加外围{len(p):,}。"
    )

    if core.empty:
        print(
            "六区内匹配点数：0。"
        )

    return counts, summary


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Extract bus and school POIs for six Nanjing districts.")
    parser.add_argument("--data-dir", type=Path, default=DATA_DIR, help="Directory containing eight_region and POI files.")
    parser.add_argument("--output-root", type=Path, default=OUTPUT_ROOT, help="Directory for timestamped output runs.")
    parser.add_argument("--buffer-m", type=float, default=BUFFER_M)
    parser.add_argument("--bus-file", type=Path, help="Bus stop Shapefile path; relative paths are resolved under --data-dir.")
    parser.add_argument("--school-file", type=Path, help="School Shapefile path; relative paths are resolved under --data-dir.")
    parser.add_argument("--encoding", help="Text encoding override for all input Shapefiles.")
    args = parser.parse_args(argv)
    if not np.isfinite(args.buffer_m) or args.buffer_m < 0:
        parser.error("--buffer-m must be a finite nonnegative number")
    return args


def main(argv=None):
    global DATA_DIR, BOUNDARY_DIR, OUTPUT_ROOT, POI_FILES, ENCODING, BUFFER_M
    args = parse_args(argv)
    DATA_DIR = args.data_dir.expanduser().resolve()
    BOUNDARY_DIR = DATA_DIR / "eight_region"
    OUTPUT_ROOT = args.output_root.expanduser().resolve()
    BUFFER_M = args.buffer_m
    POI_FILES = {
        "bus": args.bus_file or Path("公交站点") / "公交站_点.shp",
        "school": args.school_file or Path("学校教育") / "学校_点.shp",
    }
    POI_FILES = {
        tag: path.expanduser() if path.expanduser().is_absolute() else DATA_DIR / path.expanduser()
        for tag, path in POI_FILES.items()
    }
    ENCODING = {tag: args.encoding for tag in ("boundary", "bus", "school")}
    if BUFFER_M < 0:
        raise ValueError(
            "BUFFER_M不能为负数。"
        )

    paths = {
        tag: resolve_poi(path)
        for tag, path in POI_FILES.items()
    }

    boundary_paths = [
        BOUNDARY_DIR / f"{name}.shp"
        for name in DISTRICTS
    ]

    for path in boundary_paths + list(paths.values()):
        check_parts(path)

    out = OUTPUT_ROOT / datetime.now().strftime(
        "run_%Y%m%d_%H%M%S_%f"
    )

    out.mkdir(
        parents=True,
        exist_ok=False,
    )

    audit = {
        "status": "RUNNING",
        "inputs": [],
        "districts": DISTRICTS,
        "district_label_basis": (
            "District names from separate boundary filenames"
        ),
        "metric_crs": METRIC_CRS,
        "buffer_m": BUFFER_M,
        "coordinate_verification": (
            "Transform declared source CRS to EPSG:32650"
        ),
        "deduplication": (
            "All input point records retained; identical coordinates flagged"
        ),
    }

    try:
        six = load_boundaries(audit, out)

        table = pd.DataFrame(
            index=DISTRICTS + [
                "多区匹配",
                "六区合计",
            ]
        )

        table.index.name = "district"
        summaries = []

        for tag, path in paths.items():
            counts, summary = extract(
                tag,
                path,
                six,
                audit,
                out,
            )

            summaries.append(summary)

            table[tag] = counts.reindex(
                table.index,
                fill_value=0,
            )

            table.loc[
                "多区匹配", tag
            ] = summary["pending_district_assignment"]

            table.loc[
                "六区合计", tag
            ] = summary["six_records"]

        csv_out(
            table.reset_index(),
            out / "poi_district_counts.csv",
        )

        csv_out(
            pd.DataFrame(summaries),
            out / "poi_input_and_extraction_audit.csv",
        )

        audit["status"] = "COMPLETED"

        print("\n分区POI记录数：")
        print(table.to_string())
        print("\n输出：", out)

    except Exception as exc:
        audit["status"] = "FAILED"
        audit["error"] = str(exc)
        raise

    finally:
        (out / "run_info.json").write_text(
            json.dumps(
                audit,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
