from __future__ import annotations
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys
from datetime import datetime, timezone, timedelta
from uuid import uuid4

import geopandas as gpd
import numpy as np
import pandas as pd
import pyproj
import scipy
from scipy.spatial import cKDTree
import shapely
from shapely import contains_xy, union_all

from preprocess import FILES, read_matrix, convert_datenum, seconds_between
from membership import bike_gate
from relocation import (
    REFERENCE, relocation_diagnostics, scenario_specs, aggregate_period_scenarios,
)
from corridor import corridor_parameters

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "results" / "analysis"
CORE = ["玄武区", "秦淮区", "建邺区", "鼓楼区", "栖霞区", "雨花台区"]
SOURCE = "https://app.www.gov.cn/govdata/gov/202001/27/453442/article.html"


def save(df, name):
    pd.DataFrame(df).to_csv(OUT / name, index=False, encoding="utf-8-sig", float_format="%.12g")


def fingerprint(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return {"path": str(path), "sha256": h.hexdigest()}


def spatial_inputs(data_dir, need_poi=True):
    boundaries = [gpd.read_file(data_dir / "eight_region" / (n + ".shp")).to_crs(32650)
                  for n in CORE]
    region = union_all([shapely.make_valid(g) for d in boundaries for g in d.geometry])
    buffered = region.buffer(300)

    shapely.prepare(region)
    shapely.prepare(buffered)
    trees, records, sources = {}, [], []
    layers = [("bus", "公交站点", "公交站_点.shp"),
              ("school", "学校教育", "学校_点.shp")] if need_poi else []
    for label, folder, filename in layers:
        path = data_dir / folder / filename
        g = gpd.read_file(path).to_crs(32650)
        if not g.geometry.geom_type.eq("Point").all():
            raise ValueError("POI input contains non-point geometry")
        x = g.geometry.x.to_numpy(); y = g.geometry.y.to_numpy()
        valid = np.isfinite(x) & np.isfinite(y)
        inside = valid & contains_xy(region, x, y)
        candidate = valid & contains_xy(buffered, x, y)
        trees[label] = cKDTree(np.c_[x[candidate], y[candidate]])
        records.append(dict(layer=label, source_records=len(g), core_six_records=int(inside.sum()),
            core_six_unique_xy=int(len(np.unique(np.c_[x[inside],y[inside]], axis=0))),
            core_plus_300m_records=int(candidate.sum()),
            source_year=None, deduplication="none", region="six named central districts"))
        for suffix in [".shp", ".shx", ".dbf", ".prj"]:
            sources.append(fingerprint(path.with_suffix(suffix)))
    if records:
        save(records, "poi_source_audit.csv")
    for name in CORE:
        path=data_dir / "eight_region" / (name+".shp")
        for suffix in [".shp", ".shx", ".dbf", ".prj"]:
            sources.append(fingerprint(path.with_suffix(suffix)))
    return region, trees, sources


def safe_ratio(numerator, denominator, scale=1.0):

    return scale * numerator / denominator if denominator > 0 else float("nan")


def period_coverage(monthly):

    expected = {}
    for entry in FILES:
        expected.setdefault(entry[3], set()).add(entry[2])
    rows = []
    for period, group in monthly.groupby("period", sort=False):
        actual = set(group.month)
        rows.append(dict(period=period, analyzed_months=";".join(sorted(actual)),
                         expected_months=";".join(sorted(expected[period])),
                         complete_period=actual == expected[period]))
    return pd.DataFrame(rows)


def calendar_daily_counts(start, keep, seconds, exact, month):

    calendar = pd.date_range(month + "-01", periods=pd.Period(month).days_in_month)
    dates = start.dt.normalize()
    in_month = dates.isin(calendar).to_numpy()
    frame = pd.DataFrame(dict(
        date=dates, raw_trips=1, screened_trips=keep.astype(int),
        screened_seconds=np.where(keep, seconds, 0.0),
        loop_n=(exact & keep).astype(int),
        loop_hours=np.where(exact & keep, seconds / 3600, 0.0),
    ))
    daily = frame.loc[in_month].groupby("date").sum()
    daily = daily.reindex(calendar, fill_value=0).rename_axis("date").reset_index()
    daily["archive_has_records"] = daily.raw_trips.gt(0)
    daily["month"] = month
    return daily


def write_progress(tables):
    for name, rows in tables.items():
        if rows:
            save(rows, name + ".csv")


def aggregate_corridor_period(rows):

    keys = ["period", "scenario", "status", "method", "window_alignment",
            "window_min", "corridor_half_width_m", "max_angle_deg",
            "capacity_bikes", "max_detour_ratio", "require_common_interval",
            "candidate_attempt_limit"]
    additive = ["calendar_days", "events", "routes", "singleton_routes",
                "multi_event_routes", "served_by_multi_event_routes",
                "unbatched_bicycle_km", "corridor_polyline_km", "accepted_insertions",
                "candidate_attempts", "candidate_attempt_limit_hits",
                "untried_candidates_at_limit", "rejected_same_bike",
                "rejected_common_interval", "rejected_capacity",
                "rejected_detour_ratio", "rejected_no_savings"]
    maxima = ["maximum_events_per_route", "maximum_peak_load"]
    monthly = pd.DataFrame(rows)
    if monthly.empty:
        return pd.DataFrame(columns=keys + additive + maxima)
    if monthly.duplicated(["month"] + keys).any():
        raise ValueError("Duplicate month/corridor settings would double-count the period.")
    rules = {c: "sum" for c in additive}
    rules.update({c: "max" for c in maxima})
    result = monthly.groupby(keys, sort=False, dropna=False).agg(rules).reset_index()
    for name, numerator, denominator, scale in (
        ("multi_event_route_pct", "multi_event_routes", "routes", 100),
        ("multi_event_served_pct", "served_by_multi_event_routes", "events", 100),
        ("polyline_share_of_unbatched_pct", "corridor_polyline_km", "unbatched_bicycle_km", 100),
        ("corridor_polyline_km_per_calendar_day", "corridor_polyline_km", "calendar_days", 1),
    ):
        result[name] = scale * result[numerator] / result[denominator].replace(0, np.nan)
    return result


def run(args, provenance):
    data_dir = args.data_dir.resolve()
    region, trees, sources = spatial_inputs(data_dir, need_poi=not args.relocation_only)
    provenance["inputs"] = sources
    transformer = pyproj.Transformer.from_crs(4326, 32650, always_xy=True)
    tables = {name: [] for name in (
        "mat_sample_audit_monthly", "daily_count_duration_audit",
        "poi_radius_diagnostic", "straight_line_threshold_diagnostic",
        "straight_line_membership_diagnostic", "coordinate_unit_check",
        "relocation_geometry_monthly", "relocation_pair_audit",
        "relocation_filter_flow", "relocation_group_size_distribution",
        "relocation_spatial_audit", "relocation_tail_audit",
    )}
    corridor_config = None if args.skip_corridor else corridor_parameters()
    if corridor_config is not None:
        tables["relocation_corridor_monthly"] = []
        tables["relocation_corridor_group_size_distribution"] = []
    monthly = tables["mat_sample_audit_monthly"]
    relocation = tables["relocation_geometry_monthly"]
    for filename, key, month, period, csvname, paper_n, previous_n in FILES:
        if month not in args.months:
            continue
        path = data_dir / filename
        sources.append(fingerprint(path))
        print(f"Reading {filename}", flush=True)
        a = read_matrix(path, key)
        start_full = convert_datenum(a[:, 0])
        end_full = convert_datenum(a[:, 1])
        start = start_full.dt.floor("s")
        end = end_full.dt.floor("s")
        seconds = seconds_between(start, end).to_numpy()
        keep = np.isfinite(seconds) & (seconds >= 60) & (seconds <= 7200)
        microseconds = seconds_between(start_full, end_full).to_numpy()
        keepmicro = np.isfinite(microseconds) & (microseconds >= 60) & (microseconds <= 7200)
        xy = a[:, 2:6]
        numerical = (np.isfinite(xy).all(axis=1)
                     & (np.abs(xy[:, [0, 2]]) <= 180).all(axis=1)
                     & (np.abs(xy[:, [1, 3]]) <= 90).all(axis=1))
        ox, oy, dx, dy = [np.full(len(a), np.nan) for _ in range(4)]
        ox[numerical], oy[numerical] = transformer.transform(
            xy[numerical, 0], xy[numerical, 1])
        dx[numerical], dy[numerical] = transformer.transform(
            xy[numerical, 2], xy[numerical, 3])
        projected = np.isfinite(np.column_stack([ox, oy, dx, dy])).all(axis=1)
        geom = np.hypot(ox - dx, oy - dy) / 1000
        valid = numerical & projected & np.isfinite(geom)
        geometry_keep = keep & valid
        exact = valid & (xy[:, 0] == xy[:, 2]) & (xy[:, 1] == xy[:, 3])
        valid_start = start.notna().to_numpy()
        outside = valid_start & start.dt.strftime("%Y-%m").ne(month).to_numpy()
        loop_h = float(seconds[exact & keep].sum() / 3600)
        screened_h = float(seconds[keep].sum() / 3600)
        row = dict(
            month=month, period=period, raw_mat_rows=len(a), reported_trips=paper_n,
            duration_screened_rows=int(keep.sum()),
            geometry_valid_screened_rows=int(geometry_keep.sum()),
            excluded_lt60=int((seconds < 60).sum()),
            excluded_gt7200=int((seconds > 7200).sum()),
            excluded_invalid_duration=int((~np.isfinite(seconds)).sum()),
            microsecond_screened_rows=int(keepmicro.sum()),
            precision_changed_records=int((keep != keepmicro).sum()),
            exact_same_od_raw=int(exact.sum()),
            exact_same_od_screened=int((exact & keep).sum()),
            exact_same_od_screened_pct=safe_ratio((exact & keep).sum(), keep.sum(), 100),
            loop_duration_h=loop_h, screened_duration_h=screened_h,
            loop_duration_share_pct=safe_ratio(loop_h, screened_h, 100),
            exact_loop_distance_change_km_per_1kmh=loop_h,
            nonloop_geometric_under100m_screened=int((keep & valid & ~exact & (geom < .1)).sum()),
            invalid_coordinate_screened_rows=int((keep & ~valid).sum()),
            invalid_numeric_coordinate_screened_rows=int((keep & ~numerical).sum()),
            nonfinite_projection_screened_rows=int((keep & numerical & ~valid).sum()),
            invalid_start_timestamp_rows=int((~valid_start).sum()),
            raw_rows_outside_month=int(outside.sum()),
            duration_screened_rows_outside_month=int((outside & keep).sum()),
        )
        if row["raw_mat_rows"] != (row["duration_screened_rows"] + row["excluded_lt60"]
                                  + row["excluded_gt7200"] + row["excluded_invalid_duration"]):
            raise AssertionError("Trip-screen accounting does not reconcile")
        monthly.append(row)

        sample = np.flatnonzero(geometry_keep & ~exact & (geom > 0))[::1000]
        relative = np.empty(0)
        if len(sample):
            rad = np.deg2rad(xy[sample])
            dlon, dlat = rad[:, 2] - rad[:, 0], rad[:, 3] - rad[:, 1]
            h = np.clip(np.sin(dlat / 2) ** 2
                        + np.cos(rad[:, 1]) * np.cos(rad[:, 3]) * np.sin(dlon / 2) ** 2, 0, 1)
            hav = 6371.0088 * 2 * np.arctan2(np.sqrt(h), np.sqrt(1 - h))
            ok = np.isfinite(hav) & (hav > 0)
            relative = np.abs(geom[sample][ok] / hav[ok] - 1)
        tables["coordinate_unit_check"].append(dict(
            month=month, independent_great_circle_sample_n=len(relative),
            max_projected_vs_spherical_relative_error=float(relative.max()) if len(relative) else np.nan,
            median_projected_vs_spherical_relative_error=float(np.median(relative)) if len(relative) else np.nan,
            interpretation="Projected and spherical distance comparison",
        ))
        ds = calendar_daily_counts(start, keep, seconds, exact, month)
        ds["period"] = period
        tables["daily_count_duration_audit"].extend(ds.to_dict("records"))

        print(f"Candidate-relocation diagnostics for {month}", flush=True)
        diag = relocation_diagnostics(
            a, start, end, keep, ox, oy, dx, dy, valid, month, period,
            region=region, corridor_config=corridor_config)
        if corridor_config is not None:
            tables["relocation_corridor_monthly"].append(diag["corridor"]["summary"])
            tables["relocation_corridor_group_size_distribution"].extend(diag["corridor"]["group_size"])
            corridor_summary = diag["corridor"]["summary"]
            print(f"Corridor paths for {month}: events={corridor_summary['events']}, "
                  f"routes={corridor_summary['routes']}", flush=True)
        relocation.extend(diag["scenarios"])
        tables["relocation_pair_audit"].append(diag["pair_audit"])
        for key, name in (
            ("filter_flow", "relocation_filter_flow"),
            ("group_size", "relocation_group_size_distribution"),
            ("spatial_audit", "relocation_spatial_audit"),
            ("tail_audit", "relocation_tail_audit"),
        ):
            tables[name].extend(diag[key])

        if not args.relocation_only:
            gd = geom[geometry_keep]
            hard = (gd >= .8) & (gd <= 5)
            for name, w in (
                ("hard_0.8_5", hard.astype(float)),
                ("literal_maximum_all_geometric_distances", bike_gate(gd, "maximum")),
                ("normalized_bike_admissibility_all_geometric_distances", bike_gate(gd, "normalized")),
                ("literal_maximum_within_0.8_5", hard * bike_gate(gd, "maximum")),
                ("normalized_bike_admissibility_within_0.8_5", hard * bike_gate(gd, "normalized")),
            ):
                tables["straight_line_membership_diagnostic"].append(dict(
                    month=month, period=period, scenario=name,
                    screened_rows=len(gd), geometry_valid_screened_rows=len(gd),
                    duration_screened_rows=int(keep.sum()),
                    admissibility_weight_sum=float(w.sum()),
                    weighted_geometric_km=float((w * gd).sum()),
                    basis="Cycling admissibility weights on duration-screened straight-line distances",
                ))
            for lo, hi in itertools.product([.6, .8, 1.], [4., 5., 6.]):
                selected = geometry_keep & (geom >= lo) & (geom <= hi)
                n = int(selected.sum())
                tables["straight_line_threshold_diagnostic"].append(dict(
                    month=month, period=period, lower_km=lo, upper_km=hi,
                    screened_rows=int(keep.sum()),
                    geometry_valid_screened_rows=int(geometry_keep.sum()),
                    geometric_band_trips=n,
                    geometric_band_pct=safe_ratio(n, keep.sum(), 100),
                    pct_of_duration_screened=safe_ratio(n, keep.sum(), 100),
                    pct_of_geometry_valid=safe_ratio(n, geometry_keep.sum(), 100),
                    geometric_distance_sum_km=float(geom[selected].sum()),
                    basis="Straight-line distance; geometric_band_pct uses duration-screened rows",
                ))
            incore = geometry_keep & contains_xy(region, ox, oy) & contains_xy(region, dx, dy)
            points_o, points_d = np.c_[ox[incore], oy[incore]], np.c_[dx[incore], dy[incore]]
            for kind, tree in trees.items():
                do, dd = tree.query(points_o, workers=1)[0], tree.query(points_d, workers=1)[0]
                for radius in [100, 150, 300]:
                    tables["poi_radius_diagnostic"].append(dict(
                        month=month, period=period, layer=kind, radius_m=radius,
                        denominator_both_endpoints_in_core_six=int(incore.sum()),
                        origin_near=int((do <= radius).sum()),
                        destination_near=int((dd <= radius).sum()),
                        either_endpoint_near=int(((do <= radius) | (dd <= radius)).sum()),
                        both_endpoints_near=int(((do <= radius) & (dd <= radius)).sum()),
                        basis="POI proximity for trips with both endpoints strictly inside the six districts",
                    ))
        write_progress(tables)
        provenance["completed_months"].append(month)
        provenance["inputs"] = sources
        write_provenance(provenance)
        print(f"Completed {month}: raw={len(a)}, screened={keep.sum()}", flush=True)

    m = pd.DataFrame(monthly)
    coverage = period_coverage(m)
    sums = [c for c in m.columns if c not in (
        "month", "period", "exact_same_od_screened_pct", "loop_duration_share_pct")]
    p = m.groupby("period", sort=False)[sums].sum().reset_index()
    p["exact_same_od_screened_pct"] = [
        safe_ratio(n, d, 100) for n, d in zip(p.exact_same_od_screened, p.duration_screened_rows)]
    p["loop_duration_share_pct"] = [
        safe_ratio(n, d, 100) for n, d in zip(p.loop_duration_h, p.screened_duration_h)]
    p = p.merge(coverage, on="period", how="left", validate="one_to_one")
    save(p, "mat_sample_audit_period.csv")
    d = pd.DataFrame(tables["daily_count_duration_audit"])
    holiday = []
    for group in ["2020-02", "outbreak"]:
        z = d[d.month.eq(group)] if group == "2020-02" else d[d.period.eq(group)]
        if z.empty:
            continue
        if "2020-02" not in set(z.month):
            continue
        analyzed_months = set(z.month)
        expected_months = {"2020-02"} if group == "2020-02" else {"2020-02", "2020-03"}
        for last_day, name in (
            (None, "all_calendar_dates"),
            ("2020-02-02", "exclude_national_holiday_overlap"),
            ("2020-02-09", "exclude_first_nine_Feb_days_illustrative"),
        ):
            zz = z if last_day is None else z[~z.date.between(
                pd.Timestamp("2020-02-01"), pd.Timestamp(last_day))]
            holiday.append(dict(
                group=group, scenario=name, dates=len(zz),
                analyzed_months=";".join(sorted(analyzed_months)),
                complete_period=analyzed_months == expected_months,
                dates_with_archive_records=int(zz.archive_has_records.sum()),
                raw_trips=int(zz.raw_trips.sum()), screened_trips=int(zz.screened_trips.sum()),
                raw_trips_per_date=safe_ratio(zz.raw_trips.sum(), len(zz)),
                screened_trips_per_date=safe_ratio(zz.screened_trips.sum(), len(zz)),
                mean_screened_duration_min=safe_ratio(
                    zz.screened_seconds.sum(), zz.screened_trips.sum(), 1 / 60),
                source=SOURCE if name == "exclude_national_holiday_overlap" else "MAT archive calendar",
                interpretation="Aggregates over the selected calendar days",
            ))
    if holiday:
        h = pd.DataFrame(holiday)
        bases = h[h.scenario.eq("all_calendar_dates")].set_index("group").screened_trips_per_date
        h["screened_daily_count_change_pct"] = [
            100 * (v / bases[g] - 1) if bases[g] > 0 else np.nan
            for g, v in zip(h.group, h.screened_trips_per_date)]
        save(h, "holiday_count_sensitivity.csv")
    period_scenarios = aggregate_period_scenarios(relocation)
    period_scenarios = period_scenarios.merge(
        coverage, on="period", how="left", validate="many_to_one")
    save(period_scenarios, "relocation_geometry_period.csv")
    if corridor_config is not None:
        corridor_period = aggregate_corridor_period(tables["relocation_corridor_monthly"])
        corridor_period = corridor_period.merge(
            coverage, on="period", how="left", validate="many_to_one")
        save(corridor_period, "relocation_corridor_period.csv")
        provenance["corridor_period_rows"] = len(corridor_period)
    return tables, period_scenarios


def write_provenance(provenance):
    (OUT / "provenance.json").write_text(
        json.dumps(provenance, ensure_ascii=False, indent=2), encoding="utf-8")


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="Bike trip, POI and relocation analysis.")
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data",
                        help="Directory containing the four MAT files and spatial-input subfolders.")
    parser.add_argument("--output-root", type=Path, default=ROOT / "results" / "analysis",
                        help="Parent directory for timestamped analysis results.")
    parser.add_argument("--months", nargs="+", choices=[r[2] for r in FILES],
                        default=[r[2] for r in FILES], help="Monthly archives to analyse.")
    parser.add_argument("--relocation-only", action="store_true",
                        help="Run trip and relocation analyses.")
    parser.add_argument("--skip-corridor", action="store_true",
                        help="Select OD grouping for the relocation analysis.")
    args = parser.parse_args(argv)
    if len(args.months) != len(set(args.months)):
        parser.error("--months must not contain duplicates")
    return args


def main(argv=None):
    global OUT
    args = parse_args(argv)

    stamp = datetime.now(timezone(timedelta(hours=8))).strftime("%Y%m%d_%H%M%S")
    OUT = args.output_root.resolve() / f"run_{stamp}_{uuid4().hex[:8]}"
    OUT.mkdir(parents=True, exist_ok=False)
    prov = {
        "status": "running", "completed_months": [], "inputs": [],
        "scripts": [fingerprint(ROOT / name) for name in (
            Path(__file__).name, "relocation.py", "corridor.py", "preprocess.py", "membership.py")],
        "versions": {"python": sys.version, "numpy": np.__version__, "pandas": pd.__version__,
                     "scipy": scipy.__version__, "geopandas": gpd.__version__,
                     "pyproj": pyproj.__version__, "shapely": shapely.__version__},
        "parameters": {
            "months": args.months, "data_dir": str(args.data_dir.resolve()),
            "relocation_only": args.relocation_only, "duration_seconds": [60, 7200],
            "time_policy": "Local source timestamps floored to whole seconds",
            "relocation_window_policy": "Local daily windows, left-closed/right-open; 360 min gives 00-06, 06-12, 12-18, 18-24",
            "relocation_reference_scenario": REFERENCE,
            "coordinate_assumption": "Input coordinates interpreted as WGS84 and projected to EPSG:32650",
            "core_districts": CORE, "poi_radii_m": [100, 150, 300],
            "relocation_scenarios": scenario_specs(),
            "corridor_scenario": None if args.skip_corridor else corridor_parameters(),
            "corridor_input_sample": "Adjacent raw records across the input archive; both durations 60-7200 seconds, displacement >=100 m, 0<gap<=24 h",
        },
        "method": [
            "Pair adjacent raw records before duration and displacement screening.",
            "Compare OD grid groups across spatial, temporal and capacity settings.",
            "Build fixed-corridor pickup/delivery paths with interval and peak-load checks.",
            "Calculate distance thresholds, fuzzy cycling weights and POI proximity.",
        ],
    }
    write_provenance(prov)
    print(f"New output directory: {OUT}", flush=True)
    try:
        tables, period_scenarios = run(args, prov)
        prov["status"] = "completed"
        prov["output_rows"] = {name: len(rows) for name, rows in tables.items()}
        prov["output_rows"]["relocation_geometry_period"] = len(period_scenarios)
        write_provenance(prov)
        print(f"Saved aggregate diagnostics to {OUT}", flush=True)
    except Exception as exc:
        prov["status"] = "failed"
        prov["error"] = {"type": type(exc).__name__, "message": str(exc)}
        write_provenance(prov)
        raise


if __name__ == "__main__":
    main()
