from __future__ import annotations

import math
from typing import Any

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree


_METHOD = "fixed_anchor_greedy_pickup_delivery_v1"
_ALIGNMENT = "source_local_midnight"
_METRE_TOL = 1e-6
_DAY_NS = 86_400_000_000_000
_SIZE_BINS = ((1, 1, "1"), (2, 5, "2-5"), (6, 10, "6-10"),
              (11, 20, "11-20"), (21, 30, "21-30"),
              (31, 50, "31-50"), (51, math.inf, "51+"))
_COLUMNS = ("event_id", "bike", "origin_x", "origin_y", "destination_x",
            "destination_y", "previous_end", "next_start")
_COUNTERS = ("accepted_insertions", "candidate_attempts",
             "candidate_attempt_limit_hits", "untried_candidates_at_limit",
             "rejected_same_bike", "rejected_common_interval",
             "rejected_capacity", "rejected_detour_ratio", "rejected_no_savings")


def corridor_parameters() -> dict[str, Any]:


    return dict(window_min=360, corridor_half_width_m=250.0, max_angle_deg=30.0,
                capacity_bikes=20, max_detour_ratio=1.2,
                require_common_interval=True, candidate_attempt_limit=512,
                return_routes=False)


def _configuration(config):
    result = corridor_parameters()
    if config is not None:
        if not isinstance(config, dict):
            raise TypeError("config must be a dictionary or None")
        unknown = set(config) - set(result)
        if unknown:
            raise ValueError(f"Unknown corridor parameters: {sorted(unknown)}")
        result.update(config)
    for name in ("window_min", "capacity_bikes", "candidate_attempt_limit"):
        value = result[name]
        if name == "candidate_attempt_limit" and value is None:
            continue
        if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value <= 0:
            raise ValueError(f"{name} must be a positive integer" +
                             (" or None" if name == "candidate_attempt_limit" else ""))
        result[name] = int(value)
    if result["window_min"] > 1440:
        raise ValueError("window_min must be at most 1440; windows restart each local day")
    for name in ("corridor_half_width_m", "max_angle_deg", "max_detour_ratio"):
        value = result[name]
        if isinstance(value, (bool, np.bool_)):
            raise ValueError(f"{name} must be a finite number")
        try:
            value = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{name} must be a finite number") from exc
        if not math.isfinite(value):
            raise ValueError(f"{name} must be a finite number")
        result[name] = value
    if result["corridor_half_width_m"] < 0:
        raise ValueError("corridor_half_width_m cannot be negative")
    if not 0 <= result["max_angle_deg"] <= 90:
        raise ValueError("max_angle_deg must lie between 0 and 90")
    if result["max_detour_ratio"] < 1:
        raise ValueError("max_detour_ratio must be at least one")
    for name in ("require_common_interval", "return_routes"):
        if not isinstance(result[name], (bool, np.bool_)):
            raise ValueError(f"{name} must be Boolean")
        result[name] = bool(result[name])
    return result


def _ratio(numerator, denominator, scale=1.0):
    return float(scale * numerator / denominator) if denominator > 0 else math.nan


def _event_arrays(events, month):
    if not isinstance(events, pd.DataFrame):
        raise TypeError("events must be a pandas DataFrame")
    missing = set(_COLUMNS) - set(events.columns)
    if missing:
        raise ValueError(f"Missing event columns: {sorted(missing)}")

    if events.empty:
        return None
    if (not pd.api.types.is_integer_dtype(events.event_id.dtype)
            or pd.api.types.is_bool_dtype(events.event_id.dtype)
            or events.event_id.isna().any()):
        raise ValueError("event_id must contain unique, nonmissing integer identifiers")
    if events.event_id.duplicated().any():
        raise ValueError("event_id must be unique")

    if (events.event_id < np.iinfo(np.int64).min).any() or (events.event_id > np.iinfo(np.int64).max).any():
        raise ValueError("event_id must fit a signed 64-bit integer")
    ids = events.event_id.to_numpy(dtype=np.int64)
    bike = events.bike.to_numpy()
    if events.bike.isna().any():
        raise ValueError("bike identifiers must be present")
    if pd.api.types.is_numeric_dtype(events.bike.dtype) and not np.isfinite(bike).all():
        raise ValueError("numeric bike identifiers must be finite")
    try:

        for value in bike:
            hash(value)
    except TypeError as exc:
        raise ValueError("bike identifiers must be hashable scalar values") from exc
    coordinates = events[["origin_x", "origin_y", "destination_x", "destination_y"]].to_numpy(dtype=float)
    if not np.isfinite(coordinates).all():
        raise ValueError("all projected endpoint coordinates must be finite")
    lengths = np.hypot(coordinates[:, 2] - coordinates[:, 0],
                       coordinates[:, 3] - coordinates[:, 1])
    if not (np.isfinite(lengths) & (lengths > _METRE_TOL)).all():
        raise ValueError("each candidate must have a finite, positive endpoint displacement")
    previous = pd.DatetimeIndex(pd.to_datetime(events.previous_end, errors="coerce"))
    following = pd.DatetimeIndex(pd.to_datetime(events.next_start, errors="coerce"))
    if previous.tz is not None or following.tz is not None:
        raise ValueError("timestamps must use the same timezone-naive local time")
    if previous.isna().any() or following.isna().any():
        raise ValueError("event timestamps must be valid")
    previous_ns = previous.to_numpy(dtype="datetime64[ns]").astype(np.int64)
    following_ns = following.to_numpy(dtype="datetime64[ns]").astype(np.int64)
    if (previous_ns > following_ns).any():
        raise ValueError("previous_end cannot be later than next_start")
    lower = pd.Timestamp(str(pd.Period(month, freq="M")) + "-01")
    upper = lower + pd.offsets.MonthBegin(1)
    if ((previous < lower) | (previous >= upper) | (following < lower) | (following >= upper)).any():
        raise ValueError("all candidate interval endpoints must lie in the declared source month")
    return ids, bike, coordinates, lengths, previous_ns, following_ns


def _route_profile(anchor, members, pickups, deliveries, ids, xy, anchor_length,
                   *, include_stops=False):


    members = np.asarray(members, dtype=np.int64)
    count = len(members)
    if count:
        x = np.concatenate((xy[members, 0], xy[members, 2]))
        y = np.concatenate((xy[members, 1], xy[members, 3]))
        s = np.concatenate((pickups, deliveries))

        kind = np.concatenate((np.ones(count, dtype=np.int8), np.zeros(count, dtype=np.int8)))
        node_ids = np.concatenate((ids[members], ids[members]))
        order = np.lexsort((node_ids, kind, y, x, s))
        x, y, s, kind, node_ids = (v[order] for v in (x, y, s, kind, node_ids))
        load_after = 1 + np.cumsum(np.where(kind == 1, 1, -1))
        if (load_after < 1).any() or load_after[-1] != 1:
            raise AssertionError("Internal pickup/delivery order violated anchor load conservation")
        peak = max(1, int(load_after.max()))
        px = np.concatenate(([xy[anchor, 0]], x, [xy[anchor, 2]]))
        py = np.concatenate(([xy[anchor, 1]], y, [xy[anchor, 3]]))
        distance = float(np.hypot(np.diff(px), np.diff(py)).sum())
    else:
        distance, peak = float(anchor_length), 1
    stops = None
    if include_stops:
        stops = [dict(event_id=int(ids[anchor]), action="pickup", x=float(xy[anchor, 0]),
                      y=float(xy[anchor, 1]), projection_m=0.0, load_after=1)]
        if count:
            stops.extend(dict(event_id=int(eid), action="pickup" if action == 1 else "delivery",
                              x=float(nx), y=float(ny), projection_m=float(projection),
                              load_after=int(load))
                         for eid, action, nx, ny, projection, load
                         in zip(node_ids, kind, x, y, s, load_after))
        stops.append(dict(event_id=int(ids[anchor]), action="delivery", x=float(xy[anchor, 2]),
                          y=float(xy[anchor, 3]), projection_m=float(anchor_length), load_after=0))
    return distance, peak, stops


def corridor_diagnostics(events: pd.DataFrame, month: str, period: str,
                         config=None) -> dict[str, Any]:


    cfg = _configuration(config)
    source_month = pd.Period(month, freq="M")
    meta = {name: value for name, value in cfg.items() if name != "return_routes"}
    meta.update(month=str(source_month), period=period, method=_METHOD,
                window_alignment=_ALIGNMENT,
                scenario=f"corridor{cfg['corridor_half_width_m']:g}_window{cfg['window_min']}_capacity{cfg['capacity_bikes']}")
    summary = dict(meta, status="ok", calendar_days=source_month.days_in_month,
                   events=len(events), routes=0, singleton_routes=0, multi_event_routes=0,
                   served_by_multi_event_routes=0, unbatched_bicycle_km=0.0,
                   corridor_polyline_km=0.0, maximum_events_per_route=0,
                   maximum_peak_load=0, **{name: 0 for name in _COUNTERS})
    distribution = [dict(meta, bin_label=label, groups=0, events=0, corridor_polyline_km=0.0)
                    for _, _, label in _SIZE_BINS]
    route_metrics = []
    values = _event_arrays(events, str(source_month))
    if values is not None:
        ids, bike, xy, lengths, previous, following = values
        assigned = np.zeros(len(events), dtype=bool)
        day = following // _DAY_NS
        within_day = following - day * _DAY_NS
        bins_per_day = math.ceil(1440 / cfg["window_min"])
        bins = day * bins_per_day + within_day // (cfg["window_min"] * 60 * 10**9)
        ordering = np.lexsort((ids, -lengths, bins))
        changes = np.flatnonzero(np.diff(bins[ordering])) + 1
        pieces = np.split(ordering, changes)
        width = cfg["corridor_half_width_m"]
        angle_cos = math.cos(math.radians(cfg["max_angle_deg"]))
        route_length_sum = 0.0
        summary["unbatched_bicycle_km"] = float(lengths.sum() / 1000)
        for members_in_bin in pieces:
            tree = cKDTree(xy[members_in_bin, :2])
            for anchor in members_in_bin:
                if assigned[anchor]:
                    continue
                assigned[anchor] = True
                length = float(lengths[anchor])
                origin = xy[anchor, :2]
                unit = (xy[anchor, 2:] - origin) / length
                center = (origin + xy[anchor, 2:]) / 2
                near = tree.query_ball_point(center, math.hypot(length / 2, width) + _METRE_TOL)
                candidates = members_in_bin[np.asarray(near, dtype=np.int64)]
                candidates = candidates[~assigned[candidates]]
                c_offset = xy[candidates, :2] - origin
                d_offset = xy[candidates, 2:] - origin
                c_s = c_offset @ unit
                d_s = d_offset @ unit
                c_cross = c_offset[:, 0] * unit[1] - c_offset[:, 1] * unit[0]
                d_cross = d_offset[:, 0] * unit[1] - d_offset[:, 1] * unit[0]
                same_direction = (d_s - c_s) / lengths[candidates] >= angle_cos - 1e-12
                inside = ((c_s >= -_METRE_TOL) & (d_s <= length + _METRE_TOL)
                          & (d_s - c_s > _METRE_TOL)
                          & (np.abs(c_cross) <= width + _METRE_TOL)
                          & (np.abs(d_cross) <= width + _METRE_TOL) & same_direction)
                candidates, c_s, d_s = candidates[inside], c_s[inside], d_s[inside]
                rank = np.lexsort((ids[candidates], -lengths[candidates]))
                candidates = candidates[rank]
                c_s, d_s = np.clip(c_s[rank], 0, length), np.clip(d_s[rank], 0, length)
                accepted, pickup_s, delivery_s = [], [], []
                used_bikes = {bike[anchor]}
                interval_start, interval_end = int(previous[anchor]), int(following[anchor])
                route_m, peak, attempts = length, 1, 0
                for position, candidate in enumerate(candidates):
                    if assigned[candidate]:
                        continue
                    limit = cfg["candidate_attempt_limit"]
                    if limit is not None and attempts >= limit:
                        summary["candidate_attempt_limit_hits"] += 1
                        summary["untried_candidates_at_limit"] += int((~assigned[candidates[position:]]).sum())
                        break
                    attempts += 1
                    summary["candidate_attempts"] += 1
                    if bike[candidate] in used_bikes:
                        summary["rejected_same_bike"] += 1
                        continue
                    common_start = max(interval_start, int(previous[candidate]))
                    common_end = min(interval_end, int(following[candidate]))
                    if cfg["require_common_interval"] and common_start > common_end:
                        summary["rejected_common_interval"] += 1
                        continue
                    trial_members = accepted + [candidate]
                    trial_pickup = pickup_s + [float(c_s[position])]
                    trial_delivery = delivery_s + [float(d_s[position])]
                    trial_m, trial_peak, _ = _route_profile(
                        anchor, trial_members, trial_pickup, trial_delivery, ids, xy, length)
                    if trial_peak > cfg["capacity_bikes"]:
                        summary["rejected_capacity"] += 1
                        continue
                    tolerance = max(_METRE_TOL, 1e-12 * max(trial_m, route_m, length))
                    if trial_m > cfg["max_detour_ratio"] * length + tolerance:
                        summary["rejected_detour_ratio"] += 1
                        continue
                    if trial_m > route_m + lengths[candidate] + tolerance:
                        summary["rejected_no_savings"] += 1
                        continue
                    accepted, pickup_s, delivery_s = trial_members, trial_pickup, trial_delivery
                    interval_start, interval_end = common_start, common_end
                    route_m, peak = trial_m, trial_peak
                    used_bikes.add(bike[candidate])
                    assigned[candidate] = True
                    summary["accepted_insertions"] += 1
                count = len(accepted) + 1
                summary["routes"] += 1
                summary["singleton_routes"] += count == 1
                summary["multi_event_routes"] += count > 1
                summary["served_by_multi_event_routes"] += count if count > 1 else 0
                summary["maximum_events_per_route"] = max(summary["maximum_events_per_route"], count)
                summary["maximum_peak_load"] = max(summary["maximum_peak_load"], peak)
                route_length_sum += route_m
                for bucket, (lower, upper, _) in zip(distribution, _SIZE_BINS):
                    if lower <= count <= upper:
                        bucket["groups"] += 1
                        bucket["events"] += count
                        bucket["corridor_polyline_km"] += route_m / 1000
                        break
                if cfg["return_routes"]:
                    _, _, stops = _route_profile(anchor, accepted, pickup_s, delivery_s,
                                                 ids, xy, length, include_stops=True)
                    selected = [anchor] + accepted
                    has_common_interval = interval_start <= interval_end
                    route_metrics.append(dict(
                        anchor_event_id=int(ids[anchor]), event_ids=[int(ids[i]) for i in selected],
                        events=count, polyline_km=route_m / 1000,
                        unbatched_bicycle_km=float(lengths[selected].sum() / 1000),
                        peak_load=peak, window_index=int(bins[anchor]),
                        common_interval_start=pd.Timestamp(interval_start).isoformat() if has_common_interval else None,
                        common_interval_end=pd.Timestamp(interval_end).isoformat() if has_common_interval else None,
                        stops=stops))
        if not assigned.all():
            raise AssertionError("Every supplied event must be assigned to exactly one route")
        if summary["routes"] + summary["accepted_insertions"] != len(events):
            raise AssertionError("Route/event accounting does not reconcile")
        summary["corridor_polyline_km"] = route_length_sum / 1000
        if summary["corridor_polyline_km"] > summary["unbatched_bicycle_km"] + max(1e-8, len(events) * _METRE_TOL / 1000):
            raise AssertionError("Accepted polyline distances exceeded independently served displacement")
    summary["multi_event_route_pct"] = _ratio(summary["multi_event_routes"], summary["routes"], 100)
    summary["multi_event_served_pct"] = _ratio(summary["served_by_multi_event_routes"], summary["events"], 100)
    summary["polyline_share_of_unbatched_pct"] = _ratio(summary["corridor_polyline_km"], summary["unbatched_bicycle_km"], 100)
    summary["corridor_polyline_km_per_calendar_day"] = _ratio(summary["corridor_polyline_km"], summary["calendar_days"])
    summary["interpretation"] = "Deterministic greedy pickup/delivery paths along fixed corridors, measured as straight segments"
    summary["time_compatibility_note"] = "A shared instant in the intersection of all event availability intervals"
    summary["attempt_count_note"] = "Attempt/rejection counts can revisit events; untried/rejected candidates remain available as later anchors"
    return dict(summary=summary, group_size=distribution, route_metrics=route_metrics)
