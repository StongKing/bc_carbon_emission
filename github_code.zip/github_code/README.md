# Bike-sharing Analysis

本仓库包含共享单车研究中的部分代码，涵盖订单预处理、POI 提取、距离隶属度计算、候选调度位移分组及走廊取送分析。当前版本发布代码，数据另行整理。

## 文件

| 文件 | 功能 |
| --- | --- |
| `preprocess.py` | 读取 MAT 订单、转换时间、筛选骑行时长、导出订单与统计表 |
| `poi.py` | 提取南京六区内的公交站和学校 POI，生成分区统计与空间文件 |
| `membership.py` | 计算步行、自行车、汽车和公共交通的距离隶属度 |
| `relocation.py` | 识别相邻订单之间的候选调度位移，计算网格、时间窗和容量情景 |
| `corridor.py` | 构建同向走廊取送路径，计算折线距离、共同时间区间和峰值载荷 |
| `analysis.py` | 运行订单、距离阈值、隶属度、POI 邻近性和调度情景分析 |

## 环境

使用 Python 3.9–3.12。已在 Python 3.9.24 下验证。

```bash
python -m pip install -r requirements.txt
```

在本目录运行以下命令。

## 数据结构

```text
data/
├── dataoct.mat
├── datafeb.mat
├── datamarch.mat
├── datajune.mat
├── eight_region/
│   ├── 玄武区.shp
│   ├── 秦淮区.shp
│   ├── 建邺区.shp
│   ├── 鼓楼区.shp
│   ├── 栖霞区.shp
│   └── 雨花台区.shp
├── 公交站点/
│   └── 公交站_点.shp
└── 学校教育/
    └── 学校_点.shp
```

每个 Shapefile 同时放入同名的 `.shx`、`.dbf` 和 `.prj` 文件，编码文件 `.cpg` 可一同保留。

| 月份 | MAT 文件 | 变量名 |
| --- | --- | --- |
| 2019-10 | `dataoct.mat` | `dataoct` |
| 2020-02 | `datafeb.mat` | `datafeb` |
| 2020-03 | `datamarch.mat` | `datamarch` |
| 2020-06 | `datajune.mat` | `datajune` |

MAT 变量为 N × 9 数值矩阵，列顺序如下：

| 列 | 字段 | 格式 |
| --- | --- | --- |
| 1 | 起租时间 | MATLAB datenum |
| 2 | 还车时间 | MATLAB datenum |
| 3 | 起点经度 | 十进制度 |
| 4 | 起点纬度 | 十进制度 |
| 5 | 终点经度 | 十进制度 |
| 6 | 终点纬度 | 十进制度 |
| 7 | 自行车编号 | 数值 |
| 8 | 卡类型标识 | 数值 |
| 9 | 出生年份 | 数值 |

时间采用数据中的本地时钟。订单坐标按 WGS84 解释，空间距离在 EPSG:32650 下计算；空间图层使用各自声明的坐标系转换。

## 运行

处理单个月份：

```bash
python preprocess.py --data-dir data --months 2020-02
python poi.py --data-dir data
python analysis.py --data-dir data --months 2020-02
```

处理全部四个月：

```bash
python preprocess.py --data-dir data
python analysis.py --data-dir data
```

三个入口可以分别运行。`preprocess.py` 读取 MAT 文件，`poi.py` 读取区界和 POI 图层，`analysis.py` 直接读取 MAT、区界和 POI 图层。

仅运行订单统计与调度分析时，使用 MAT 和六区区界：

```bash
python analysis.py --data-dir data --months 2020-02 --relocation-only
```

`--months` 支持一次选择多个月份，例如 `--months 2020-02 2020-03`。三个入口均支持 `--output-root` 指定输出根目录，并在其下创建独立的 `run_*` 目录。

| 入口 | 可选参数 |
| --- | --- |
| `preprocess.py` | `--time-policy source_seconds` 或 `preserve_microseconds`；`--chunk-size 100000` |
| `poi.py` | `--buffer-m 300`；`--bus-file`；`--school-file`；`--encoding` |
| `analysis.py` | `--relocation-only`；`--skip-corridor` |

自定义 POI 文件的相对路径以 `--data-dir` 为基准。`--skip-corridor` 选择 OD 分组调度分析。完整参数可通过 `python 文件名.py --help` 查看。

## 计算设置与输出

订单预处理默认将起止时间截取到整秒，保留 60–7200 秒的骑行记录。OD 参考情景使用 500 m 网格、60 min 时间窗、20 辆容量、至少 100 m 位移，以及大于 0 且不超过 24 h 的订单间隔。情景分析共包含 47 组参数设置，时间窗为 30、60、120 和 360 min。

走廊分析采用固定方向的贪心取送路径，默认使用 360 min 时间窗、250 m 半宽、30° 方向夹角、20 辆峰值载荷和 1.2 倍路径长度上限。距离为取送点之间的直线段长度之和。隶属度和距离阈值分析使用订单起终点的直线距离；POI 邻近性使用 100、150 和 300 m 半径。

| 输出目录 | 主要内容 |
| --- | --- |
| `results/preprocess/run_*/` | 全量、筛选后、剔除及时间精度差异订单，逐日、月度、时期及单车统计 |
| `results/poi/run_*/` | 六区 POI、缓冲区 POI、分区数量、属性统计及 GeoPackage |
| `results/analysis/run_*/` | 样本统计、距离阈值、隶属度、POI 半径、OD 情景和走廊路径汇总 |

每次运行同时保存参数、输入文件指纹和运行状态。`.gitignore` 已配置数据、结果及 Python 缓存的忽略规则。
